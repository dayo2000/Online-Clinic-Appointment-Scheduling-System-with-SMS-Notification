<?php
	include("database.php");
	include("session.php");
?>

<!DOCTYPE html>
<html>
<head>
	<title>CLinEx</title>
	<link rel="icon" href="doctor.png">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
<style type="text/css">
* {
		padding: 0;
		margin: 0;
		box-sizing: border-box;
		font-family: arial, sans-serif;
		}
		.header {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 15px 30px;
			background: #23242b;
			color: #fff;
		}
		.u-name {
			font-size: 20px;
			padding-left: 17px;
		}
		.u-name b {
			color: #127b8e;
		}
		.header i {
			font-size: 30px;
			cursor: pointer;
			color: #fff;
		}
		.header i:hover {
			color: #127b8e;
		}
		.header h3{
			font-size: 20px;
		}
		.user-p {
			text-align: center;
			padding-left: 10px;
			padding-top: 25px;
		}
		.user-p img {
			width: 100px;
			border-radius: 50%;
		}
		.user-p h4 {
			color: #ccc;
			padding: 5px 0;

		}
		.side-bar {
			width: 250px;
			background: #262931;
			min-height: 100vh;
			transition: 500ms width;
		}
		.body {
			display: flex;
		}
		.section-1 {
			width: 100%;
			background: url("");
			background-size: cover;
			background-position: center;
			display: flex;
			flex-direction: column;
		}
		.side-bar ul {
			margin-top: 20px;
			list-style: none;
		}
		.side-bar ul li {
			font-size: 16px;
			padding: 15px 0px;
			padding-left: 20px;
			transition: 500ms background;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}
		.side-bar ul li:hover {
			background: #127b8e;
		}
		.side-bar ul li a {
			text-decoration: none;
			color: #eee;
			cursor: pointer;
			letter-spacing: 1px;
		}
		.side-bar ul li a i {
			display: inline-block;
			padding-right: 10px;
			font-size: 23px;
		}
		#navbtn {
			display: inline-block;
			margin-left: 70px;
			font-size: 20px;
			transition: 500ms color;
		}
		#checkbox {
			display: none;
		}
		#checkbox:checked ~ .body .side-bar {
			width: 60px;
		}
		#checkbox:checked ~ .body .side-bar .user-p{
			visibility: hidden;
		}
		#checkbox:checked ~ .body .side-bar a span{
			display: none;
		}
		
		.navi {
			width: 80px;
			padding-top: 30px;
		}
		h5{
			font-size: 30px;
		}
		.home-content .overview-boxes{
		  display: flex;
		  align-items: center;
		  justify-content: space-between;
		  flex-wrap: wrap;
		  padding: 0 20px;
		  margin-top: 10%;
		}
		
		.overview-boxes .box-topic{
		  font-size: 20px;
		  font-weight: 500;
		}
		.home-content .box .number{
		  display: inline-block;
		  font-size: 35px;
		  margin-top: -6px;
		  font-weight: 500;
		}
		.home-content .box .indicator{
		  display: flex;
		  align-items: center;
		}
		.home-content .indicator i{
		  height: 20px;
		  width: 20px;
		  background: #8FDACB;
		  line-height: 20px;
		  text-align: center;
		  border-radius: 50%;
		  color: #fff;
		  font-size: 20px;
		  margin-right: 5px;
		}
		
		.box > .icon { text-align: center; position: relative; }
		.box > .icon > .image { position: relative; z-index: 2; margin: auto; width: 88px; height: 88px; border: 8px solid white; line-height: 88px; border-radius: 50%; background: #63B76C; vertical-align: middle; }
		.box > .icon:hover > .image { background: #127b8e; }
		.box > .icon > .image > i { font-size: 36px !important; color: #fff !important; }
		.box > .icon:hover > .image > i { color: white !important; }
		.box > .icon > .info { margin-top: -24px; background: rgba(0, 0, 0, 0.04); border: 1px solid #e0e0e0; padding: 40px; }
		.box > .icon:hover > .info { background: rgba(0, 0, 0, 0.04); border-color: #e0e0e0; color: #127b8e; }
		.box > .icon > .info > h3.title { font-family: "Roboto",sans-serif !important; font-size: 16px; color: #222; font-weight: 500; }
		.box > .icon > .info > p { font-family: "Roboto",sans-serif !important; font-size: 13px; color: #666; line-height: 1.5em; margin: 20px;}
		.box > .icon:hover > .info > h3.title, .box > .icon:hover > .info > p, .box > .icon:hover > .info > .more > a { color: #127b8e; }
		.box > .icon > .info > .more a { font-family: "Roboto",sans-serif !important; font-size: 12px; color: #222; line-height: 12px; text-transform: uppercase; text-decoration: none; }
		.box > .icon:hover > .info > .more > a { color: #127b8e; padding: 6px 8px; background-color: #63B76C; }
		.box .space { height: 30px; }
</style>	
</head>
<body>
	<input type="checkbox" id="checkbox">
	<header class="header">
		<h2 class="u-name">Clin <b>Ex</b>
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
		<h3>Dashboard</h3>
	</header>
	<div class="body">
		<nav class="side-bar">
			<div class="user-p">
				<?php
					$select = mysqli_query($con, "SELECT * FROM registration WHERE username = '$_SESSION[username]'");

					while ($count = mysqli_fetch_array($select)) {
				?>	
				<h4><?php echo "Dra. " .$count['firstname'] .$count['lastname']; ?></h4>
				<?php
					}
				?>
			</div>
			<ul>
				<li>
					<a href="dashboard.php">
						<i class="fa fa-dashboard" aria-hidden="true"></i>
						<span>Dashboard</span>
					</a>
				</li>
				<li>
					<a href="doctor.php">
						<i class="fa fa-user-md" aria-hidden="true"></i>
						<span>Doctor</span>
					</a>
				</li>
				<li>
					<a href="patient.php">
						<i class="fa fa-stethoscope" aria-hidden="true"></i>
						<span>Patient</span>
					</a>
				</li>
				<li>
					<a href="appointment.php">
						<i class="fa fa-calendar" aria-hidden="true"></i>
						<span>Appointment</span>
					</a>
				</li>
				<li>
					<a href="record.php">
						<i class="	fa fa-address-book" aria-hidden="true"></i>
						<span>Record</span>
					</a>
				</li>
				<li>
					<a href="logout.php">
						<i class="fa fa-sign-out" aria-hidden="true"></i>
						<span>Logout</span>
					</a>
				</li>
			</ul>
		</nav>
		<form class="section-1">
				<div class="home-content">
			      <div class="overview-boxes">
			        <div class="box">
						<div class="icon">
							<div class="image"><i class='bx bxs-hourglass'></i></div>
							<div class="info">
								<h4 class="title">Total Pending</h4>
								<h1>
								<?php
									require 'database.php';

									$query = "SELECT * FROM appointments WHERE stat = 0 ORDER BY stat = 0";
									$query_run = mysqli_query($con, $query);

									$row = mysqli_num_rows($query_run);

									echo $row;
								?>
								</h1>
								<div class="more">
									<a href="#" title="Title Link">
									<div class="indicator">
										<i class='bx bx-pulse'></i>
										<span class="text">ClinEx Clinic</span>
									</div>
									</a>
								</div>
							</div>
						</div>
						<div class="space"></div>

			        </div>
					<div class="box">
						<div class="icon">
							<div class="image"><i class='bx bxs-user'></i></div>
							<div class="info">
								<h4 class="title">Total Patient</h4>
								<h1>
								<?php
								require 'database.php';

								$query = "SELECT * FROM appointments WHERE stat = 1 ORDER BY stat = 1";
								$query_run = mysqli_query($con, $query);

								$row = mysqli_num_rows($query_run);

								echo $row;
								?>
								</h1>
								<div class="more">
									<a href="#" title="Title Link">
									<div class="indicator">
										<i class='bx bx-pulse'></i>
										<span class="text">ClinEx Clinic</span>
									</div>
									</a>
								</div>
							</div>
						</div>
						<div class="space"></div>
			        </div>
					<div class="box">
						<div class="icon">
							<div class="image"><i class='bx bxs-check-shield'></i></div>
							<div class="info">
								<h4 class="title">Complete Patient</h4>
								<h1>
								<?php
								require 'database.php';

								$query = "SELECT * FROM appointments WHERE stat = 3 ORDER BY stat = 3";
								$query_run = mysqli_query($con, $query);

								$row = mysqli_num_rows($query_run);

								echo $row;
								?>
								</h1>
								<div class="more">
									<a href="#" title="Title Link">
									<div class="indicator">
										<i class='bx bx-pulse'></i>
										<span class="text">ClinEx Clinic</span>
									</div>
									</a>
								</div>
							</div>
						</div>
						<div class="space"></div>
			        </div>
					<div class="box">
						<div class="icon">
							<div class="image"><i class='bx bxs-hourglass'></i></div>
							<div class="info">
								<h4 class="title">Registered Patient</h4>
								<h1>
								<?php
								require 'database.php';

								$query = "SELECT id FROM user ORDER BY id";
								$query_run = mysqli_query($con, $query);

								$row = mysqli_num_rows($query_run);

								echo $row;
								?>
								</h1>
								<div class="more">
									<a href="#" title="Title Link">
									<div class="indicator">
										<i class='bx bx-pulse'></i>
										<span class="text">ClinEx Clinic</span>
									</div>
									</a>
								</div>
							</div>
						</div>
						<div class="space"></div>
			        </div>
			        
			        
			      </div>
		</form>
	</div>
</body>
</html>