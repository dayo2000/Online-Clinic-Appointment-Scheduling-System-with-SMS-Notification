<?php 
 
// Update the path below to your autoload.php, 
// see https://getcomposer.org/doc/01-basic-usage.md 
require_once 'vendor/autoload.php'; 
              use Twilio\Rest\Client;

              $sid    = "AC9865fd1b9036e52a8370af579414951e"; 
              $token  = "7dd9e0502853d39115bb1ce657ac0f1e"; 
              $twilio = new Client($sid, $token); 
               
              $message = $twilio->messages 
                                ->create("+639266248258", // to 
                                         array(  
                                             "messagingServiceSid" => "MG5da9e592a53e0d1aca9e1c20b0766f3f",      
                                             "body" => "Your appointment has been accepted by Dra. unknown in Talavera Clinic. See you!" 
                                         ) 
                                ); 
               
              echo "<script>alert('accepted');window.location.href='appointment.php'</script>";
?>