<?php
	include ("session.php");
	include ("database.php");
	
?>

<!DOCTYPE html>
<html>
<head>
	<title>CLinEx</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
* {
		padding: 0;
		margin: 0;
		box-sizing: border-box;
		font-family: arial, sans-serif;
		}
		.header {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 15px 30px;
			background: #23242b;
			color: #fff;
		}
		.u-name {
			font-size: 20px;
			padding-left: 17px;
		}
		.u-name b {
			color: #127b8e;
		}
		.header i {
			font-size: 30px;
			cursor: pointer;
			color: #fff;
		}
		.header i:hover {
			color: #127b8e;
		}
		.user-p {
			text-align: center;
			padding-left: 10px;
			padding-top: 25px;
		}
		.user-p img {
			width: 100px;
			border-radius: 50%;
		}
		.user-p h4 {
			color: #ccc;
			padding: 5px 0;

		}
		.side-bar {
			width: 250px;
			background: #262931;
			min-height: 100vh;
			transition: 500ms width;
		}
		.body {
			display: flex;
		}
		.section-1 {
			width: 100%;
			background: url("");
			background-size: cover;
			background-position: center;
			display: flex;
			flex-direction: column;
		}
		.side-bar ul {
			margin-top: 20px;
			list-style: none;
		}
		.side-bar ul li {
			font-size: 16px;
			padding: 15px 0px;
			padding-left: 20px;
			transition: 500ms background;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}
		.side-bar ul li:hover {
			background: #127b8e;
		}
		.side-bar ul li a {
			text-decoration: none;
			color: #eee;
			cursor: pointer;
			letter-spacing: 1px;
		}
		.side-bar ul li a i {
			display: inline-block;
			padding-right: 10px;
			font-size: 23px;
		}
		#navbtn {
			display: inline-block;
			margin-left: 70px;
			font-size: 20px;
			transition: 500ms color;
		}
		#checkbox {
			display: none;
		}
		#checkbox:checked ~ .body .side-bar {
			width: 60px;
		}
		#checkbox:checked ~ .body .side-bar .user-p{
			visibility: hidden;
		}
		#checkbox:checked ~ .body .side-bar a span{
			display: none;
		}
		
		.navi {
			width: 80px;
			padding-top: 30px;
		}
		h1 {
			text-align:center;
			font-size: 30px;
			color:   #004F13;
			margin-left: -35px;
			margin-top: 50px;
		}
		table {
			margin-left: auto;
			margin-right:auto;
			margin-bottom: 20px;

		}
		select {
			height: 32px;
			width: 100%;
			color: black;
			border: 1px solid #c2c2c2;
			border-radius: 5px;
		}

		input {
			width: 200px;
			height: 30px;
			color: black;
			border: 1px solid #c2c2c2;
			border-radius: 5px;

		}
		.edit{
			border: 1px solid #23242b;
			padding: 8px 25px;
			color: #fff;
			background-color:  #F3B40A;
			margin-left: 101%;
		}
</style>	
</head>
<body>
	<input type="checkbox" id="checkbox">
	<header class="header">
		<h2 class="u-name">Clin <b>Ex</b>
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
		</h2>
	</header>
	<div class="body">
		<nav class="side-bar">
			<div class="user-p">
				<?php
					$select = mysqli_query($con, "SELECT * FROM registration WHERE username = '$_SESSION[username]'");

					while ($count = mysqli_fetch_array($select)) {
				?>	
				<h4><?php echo "Dra. " .$count['firstname'] .$count['lastname']; ?></h4>
				<?php
					}
				?>
			</div>
			<ul>
				<li>
					<a href="doctor.php">
						<i class="fa fa-user-md" aria-hidden="true"></i>
						<span>Doctor</span>
					</a>
				</li>
				<li>
					<a href="patient.php">
						<i class="fa fa-stethoscope" aria-hidden="true"></i>
						<span>Patient</span>
					</a>
				</li>
				<li>
					<a href="appointment.php">
						<i class="fa fa-calendar" aria-hidden="true"></i>
						<span>Appointment</span>
					</a>
				</li>
				<li>
					<a href="record.php">
						<i class="	fa fa-address-book" aria-hidden="true"></i>
						<span>Record</span>
					</a>
				</li>
				<li>
					<a href="logout.php">
						<i class="fa fa-sign-out" aria-hidden="true"></i>
						<span>Logout</span>
					</a>
				</li>
			</ul>
		</nav>
		<section class="section-1">
			<div>
				<table>
					<h1>ADD DOCTOR SCHEDULE</h1>
					<tr>
						<td class="navi"><a href="add.php" class="fa fa-plus" style="font-size:45px;color:red"></a></td>
						<td class="navi"><a href="view.php" class="fa fa-eye" style="font-size:45px;color:red"></a></td>
						<td class="navi"><a href="edit.php" class="fa fa-edit" style="font-size:45px;color:red"></a></td>
						<td class="navi"><a href="delete.php" class="fa fa-trash-o" style="font-size:45px;color:red"></a></td>
					</tr>
				</table>
			</div>
			<br>
			<br>
			<br>
		<form method="POST">
		<table>
			<tr>
	            <td>FIRSTNAME</td>
	            <td>
	                <input type="text" name="firstname" required="">
	            </td>
	        </tr>
	        <tr>
	            <td>LASTNAME</td>
	            <td>
	                <input type="text" name="lastname" required="">
	            </td>
	        </tr>
	        <tr>
	            <td>SPECIAL</td>
	            <td>
	                <select name="doctor" required="">
                             <option class="hidden" selected="" disabled="">Special</option>
                             <option name="doctor" value="oby gyne">Oby gyne</option>
                             <option name="doctor" value="pediatrician">Ob gyne/Pediatrician</option>
                    </select>
	            </td>
	        </tr>
	         <tr>
	            <td>CONTACT</td>
	            <td>
	                <input type="text" name="contact" value="+63" pattern="[+]63[-][0-9]{3}[-][0-9]{4}[-][0-9]{3}" maxlength="20" class="form-control" required="">
	            </td>
	        </tr>
	        <tr>
	            <td>MONDAY</td>
	            <td>
	                <input type="time" name="mon">
	            </td>
	        </tr>
	        <tr>
	            <td>TUESDAY</td>
	            <td>
	                <input type="time" name="tues">
	            </td>
	        </tr>
	        <tr>
	            <td>WEDNESDAY</td>
	            <td>
	                <input type="time" name="wed">
	            </td>
	        </tr>
	        <tr>
	            <td>THURSDAY</td>
	            <td>
	                <input type="time" name="thur">
	            </td>
	        </tr>
	        <tr>
	            <td>FRIDAY</td>
	            <td>
	                <input type="time" name="fri">
	            </td>
	        </tr>
	        <tr>
	            <td>SATURDAY</td>
	            <td>
	                <input type="time" name="sat">
	            </td>
	        </tr>
	        <tr>
	            <td>SUNDAY</td>
	            <td>
	                <input type="time" name="sun">
	            </td>
	        </tr>
				<tr>
					<td><input type="submit" name="save" value="Save" class="edit"></td>
				</tr>
			</table>
		</form>
	<?php 
		if(isset($_POST['save'])){
			$firstname = $_POST['firstname'];
			$lastname = $_POST['lastname'];
			$doctor = $_POST['doctor'];
			$contact = $_POST['contact'];
			$mon = $_POST['mon'];
			$tues = $_POST['tues'];
			$wed = $_POST['wed'];
			$thur = $_POST['thur'];
			$fri = $_POST['fri'];
			$sat = $_POST['sat'];
			$sun = $_POST['sun'];

			$insert = mysqli_query($con, "INSERT INTO schedule (id, firstname, lastname, doctor, contact, mon, tues, wed, thur, fri, sat, sun) VALUES ('$id','$firstname','$lastname', '$doctor','$contact','$mon', '$tues', '$wed', '$thur', '$fri', '$sat', '$sun')");
			if(!$insert)
				echo "<script>alert('Unable to save!');</script>";
			else
				echo "<script>alert('Successfully saved!');</script>";
		}
	?>
	</section>

</body>
</html>