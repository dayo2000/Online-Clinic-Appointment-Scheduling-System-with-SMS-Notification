<?php

    $table = 'appointments';
    
    // Table's primary key
    $primaryKey = 'id';
    
    // Array of database columns which should be read and sent back to DataTables.
    // The `db` parameter represents the column name in the database, while the `dt`
    // parameter represents the DataTables column identifier. In this case object
    // parameter names
    $columns = array(
        array( 'db' => 'patient_id', 'dt' => 'patient_id' ),
        array( 'db' => 'patient_name',  'dt' => 'patient_name' ),
        array( 'db' => 'patient_address',   'dt' => 'patient_address' ),
        array( 'db' => 'patient_contact',   'dt' => 'patient_contact' ),
        array( 'db' => 'date',   'dt' => 'date' ),
        array( 'db' => 'startTime',   'dt' => 'startTime' ),
        array( 'db' => 'endTime',   'dt' => 'endTime' ),
        array( 'db' => 'id',   'dt' => 'id' ),
    );
    
    // SQL server connection information
    $sql_details = array(
        'user' => 'root',
        'pass' => '',
        'db'   => 'capstone',
        'host' => 'localhost'
    );
    
    
    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
    * If you just want to use the basic configuration for DataTables with PHP
    * server-side, there is no need to edit below this line.
    */
    
    require( 'ssp.class.php' );
    $where = "stat='3'";
    echo json_encode(
        SSP::complex( $_POST, $sql_details, $table, $primaryKey, $columns, $where )
    );

?>