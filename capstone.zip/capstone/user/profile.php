<?php
	include("database.php");
	include("session.php");
?>

<!DOCTYPE html>
<html>
<head>
	<title>CLinEx</title>
	<link rel="icon" href="img/doctor.png">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style type="text/css">
* {
		padding: 0;
		margin: 0;
		box-sizing: border-box;
		font-family: arial, sans-serif;
		}
		.header {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 15px 30px;
			background: #300744;
			color: #fff; 
		}
		.u-name {
			font-size: 20px;
			padding-left: 17px;
		}
		.u-name b {
			color: #127b8e;
		}
		.header i {
			font-size: 30px;
			cursor: pointer;
			color: #fff;
		}
		.header i:hover {
			color: #127b8e;
		}
		.user-p {
			text-align: center;
			padding-left: 10px;
			padding-top: 25px;
		}
		.user-p img {
			width: 100px;
			border-radius: 50%;
		}
		.user-p h4 {
			color: #ccc;
			padding: 5px 0;

		}
		.side-bar {
			width: 250px;
			background: #480965;
			min-height: 100vh;
			transition: 500ms width;
		}
		.body {
			display: flex;
		}
		.section-1 {
			width: 100%;
			background: url("");
			background-size: cover;
			background-position: center;
			display: flex;
			flex-direction: column;
		}
		.side-bar ul {
			margin-top: 20px;
			list-style: none;
		}
		.side-bar ul li {
			font-size: 16px;
			padding: 15px 0px;
			padding-left: 20px;
			transition: 500ms background;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}
		.side-bar ul li:hover {
			background: #D085EC;
		}
		.side-bar ul li a {
			text-decoration: none;
			color: white;
			cursor: pointer;
			letter-spacing: 1px;
		}
		.side-bar ul li a i {
			display: inline-block;
			padding-right: 10px;
			font-size: 23px;
		}
		#navbtn {
			display: inline-block;
			margin-left: 70px;
			font-size: 20px;
			transition: 500ms color;
		}
		#checkbox {
			display: none;
		}
		#checkbox:checked ~ .body .side-bar {
			width: 60px;
		}
		#checkbox:checked ~ .body .side-bar .user-p{
			visibility: hidden;
		}
		#checkbox:checked ~ .body .side-bar a span{
			display: none;
		}
		.navi {
			width: 80px;
			padding-top: 30px;
		}
		h5 {
			text-align:center;
			font-size: 30px;
			color:   #004F13;
			margin-left: -30px;
			margin-top: 50px;
		}
				/* Main */
		.main {
		    margin-top: -24%;
		    margin-left: 40%;
		    font-size: 28px;
		    padding: 0 10px;
		    width: 50%;
		}

		.main .card {
		    background-color: #fff;
		    border-radius: 18px;
		    box-shadow: 1px 1px 10px 0 #7D3C98;
		    height: auto;
		    margin-bottom: 20px;
		    padding: 20px 0 20px 50px;
		}

		.main .card table {
		    border: none;
		    font-size: 16px;
		    height: 270px;
		    width: 80%;
		}

		.edit {
		    position: absolute;
		    color: #e7e7e8;
		    right: 14%;
		}
		.main2 {
		    margin-top: 5%;
		    margin-left: 10%;
		    font-size: 18px;
		    padding: 0 10px;
		    width: 30%;
		}

		.main2 .card2 {
		    background-color: #fff;
		    border-radius: 18px;
		    box-shadow: 1px 1px 10px 0 #7D3C98;
		    height: auto;
		    margin-bottom: 20px;
		    padding: 20px 0 20px 50px;

		}

		.main2 .card2 table {
		    border: none;
		    font-size: 16px;
		    width: 50%;
		}
		.profile {
		    text-align: center;
		    margin-right: 15%;
		}

</style>	
</head>
<body>
	<input type="checkbox" id="checkbox">
	<header class="header">
		<h2 class="u-name">Clin <b>Ex</b>
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
	</header>
	<div class="body">
		<nav class="side-bar">
			<div class="user-p">
				<?php
					$select = mysqli_query($con, "SELECT * FROM user WHERE username = '$_SESSION[username]'");

					while ($count = mysqli_fetch_array($select)) {
				?>	
				<h4><?php echo $count['firstname'] . " " .$count['lastname']; ?></h4>
				<?php
					}
				?>
			</div>
			<ul>
				<li>
					<a href="doctor.php">
						<i class="fa fa-user-md" aria-hidden="true"></i>
						<span>Doctor</span>
					</a>
				</li>
				<li>
					<a href="appointment.php">
						<i class="fa fa-calendar" aria-hidden="true"></i>
						<span>Appointment</span>
					</a>
				</li>
				<li>
					<a href="profile.php">
						<i class="fa fa-user" aria-hidden="true"></i>
						<span>Profile</span>
					</a>
				</li>
				<li>
					<a href="setting.php">
						<i class="fa fa-gear" aria-hidden="true"></i>
						<span>Setting</span>
					</a>
				</li>
				<li>
					<a href="logout.php">
						<i class="fa fa-sign-out" aria-hidden="true"></i>
						<span>Logout</span>
					</a>
				</li>
			</ul>
		</nav>
		<form class="section-1">
			<h5>PATIENT PROFILE</h5>
						<br>
						<div class="main2">
					        <div class="card2">
					            <div class="card-body">
					                <table>
					                    <tbody>
					                    	<?php
									          		$select = mysqli_query($con, "SELECT * FROM user WHERE username = '$_SESSION[username]'");

									          		while ($count = mysqli_fetch_array($select)) {
									          	?>
									          	 <p>
									          	 	<div class="profile">
           										 	<center></center><img src="img/user.png" alt="" width="100" height="100"></center>
            										</div>
									            	<br>
									            	<strong><?php echo $count['firstname'] ." ".$count['lastname']; ?></strong><br>
									            	<br>
									            	<strong>Email: </strong><?php echo $count['email']; ?><br>
									            	<strong>Username: </strong><?php echo $count['username']; ?><br>
									            </p>
					                    </tbody>
					                </table>
					            </div>
					        </div>
					    </div>
						<div class="main">
					        <div class="card">
					            <div class="card-body">
					                <table>
					                    <tbody>
					                    	<?php
									          		$select = mysqli_query($con, "SELECT * FROM user WHERE username = '$_SESSION[username]'");

									          		while ($count = mysqli_fetch_array($select)) {
									          	?>
									          	<strong><i class='fa fa-clone' ><b>GENERAL INFORMATION</b></i></strong>
									          	<br>
									          	<br>
					                        <tr>
					                            <td><strong>Firtsname</strong></td>
					                            <td>:</td>
					                            <td width="40%"><?php echo $count['firstname']; ?></td>
					                        </tr>
					                        <tr>
					                            <td><strong>Lastname</strong></td>
					                            <td>:</td>
					                            <td width="40%"><?php echo $count['lastname']; ?></td>
					                        </tr>
					                        <tr>
					                            <td><strong>Birthday</strong></td>
					                            <td>:</td>
					                            <td width="40%"><?php echo $count['month'] ." " .$count['day'] ."," .$count['year'];?></td>
					                        </tr>
					                        <tr>
					                            <td><strong>Mobile Number</strong></td>
					                            <td>:</td>
					                            <td width="40%"><?php echo $count['contact']; ?></td>
					                        </tr>
					                        <tr>
					                            <td><strong>Address</strong></td>
					                            <td>:</td>
					                            <td width="40%"><?php echo $count['address']; ?></td>
					                        </tr>
					                    </tbody>
					                </table>
					            </div>
					        </div>
								    <?php
										}
									?>

					    <?php
							}
						?>
					    <!-- End -->
		</form>
	</div>
</body>
</html>