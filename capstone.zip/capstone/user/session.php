<?php
	include 'database.php';
	session_start();
	$select = mysqli_query($con, "SELECT * FROM user WHERE username = '$_SESSION[username]' AND password = '$_SESSION[password]'");
	$count = mysqli_num_rows($select);
	if($count==0)
		//echo "<script>alert('Restricted Page!'); window.location.href='login.php';</script>";*/
		header("location:login.php");
?>