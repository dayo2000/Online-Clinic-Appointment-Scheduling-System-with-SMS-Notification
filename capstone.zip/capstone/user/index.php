<?php
    include ('database.php');
    ob_start();
?>
<html>
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        .register{
            background: -webkit-linear-gradient(left,#653d84, #332042);
            padding: 3%;
            height: 100%;
            max-width: 200%;
        }
        .register-left{
            text-align: center;
            color: #fff;
            margin-top: 10%;
        }
        .register-left input{
            border: none;
            border-radius: 1.5rem;
            padding: 2%;
            width: 60%;
            background: #f8f9fa;
            font-weight: bold;
            color: #383d41;
            margin-top: 40%;
            margin-bottom: 3%;
            cursor: pointer;
        }
        .register-right{
            background: #f8f9fa;
            border-top-left-radius: 10% 50%;
            border-bottom-left-radius: 10% 50%;
        }
        .register-left img{
            margin-top: 15%;
            margin-bottom: 5%;
            width: 50%;
            -webkit-animation: mover 2s infinite  alternate;
            animation: mover 1s infinite  alternate;
        }
        @-webkit-keyframes mover {
            0% { transform: translateY(0); }
            100% { transform: translateY(-20px); }
        }
        @keyframes mover {
            0% { transform: translateY(0); }
            100% { transform: translateY(-20px); }
        }
        .register-left p{
            font-weight: lighter;
            padding: 12%;
            margin-top: -9%;
        }
        .register .register-form{
            padding: 10%;
            margin-top: 10%;
        }
        .btnRegister{
            float: right;
            margin-top: 10%;
            border: none;
            border-radius: 1.5rem;
            padding: 2%;
            background: #653d84;
            color: #fff;
            font-weight: 600;
            width: 50%;
            cursor: pointer;
        }
        .register-heading{
            text-align: center;
            margin-top: 8%;
            margin-bottom: -15%;
            color: #495057;
        }
</style>
</head>
<body>
    <div class="container register">
                <div class="row">
                    <div class="col-md-3 register-left">
                        <img src="https://i.pinimg.com/originals/e3/7e/14/e37e14e207070d62cfc4d0b050f3ad91.png" alt="">
                        <h3>Welcome Back to Clinex</h3>
                        <p>To keep connected with us please login with your personal info</p>
                    <a href="login.php">
                        <input type="submit" name="login" value="Login"><br>
                    </a>
                </div>
                <div class="col-md-9 register-right">
                    </form method="POST">
                            <div class="tab-pane fade show active" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                <form method="POST">
                                 <h3 class="register-heading">Sign Up</h3>
                                 <div class="row register-form">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" name="firstname" class="form-control" placeholder="First Name *" maxlength="20" required="">
                                        </div>
                                        <div class="form-group">
                                            <input type="text"  name="lastname" class="form-control" placeholder="Last Name *" maxlength="20" required="">
                                        </div>
                                        <div class="form-group">
                                            <input type="email" name="email" class="form-control" placeholder="Email *" maxlength="30" required="">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" name="contact" value="+63" pattern="[+]63[-][0-9]{3}[-][0-9]{4}[-][0-9]{3}" maxlength="20" class="form-control" required="">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" name="address" class="form-control" placeholder="Address" maxlength="50" required="">
                                        </div>
                                        <div class="form-group">
                                            <select class="month" name="month" required="" style="width: 185px; padding: 6px; border: 1px solid #dcdcdc; border-radius: 5px;">
                                                <?php
                                                    echo "<option>- Month -</option>";
                                                    echo "<option>January</option>";
                                                    echo "<option>February</option>";
                                                    echo "<option>March</option>";
                                                    echo "<option>April</option>";
                                                    echo "<option>May</option>";
                                                    echo "<option>June</option>";
                                                    echo "<option>July</option>";
                                                    echo "<option>August</option>";
                                                    echo "<option>September</option>";
                                                    echo "<option>October</option>";
                                                    echo "<option>November</option>";
                                                    echo "<option>December</option>";
                                                ?>
                                            </select>
                                            <select class="day" name="day" required="" style="padding: 6px; border: 1px solid #dcdcdc; border-radius: 5px;">
                                                <?php
                                                echo "<option>- Day -</option>";
                                                    $d = 1;
                                                    while($d <= 31){
                                                        echo "<option value = '$d'>" .$d ."</option>";
                                                        $d++;
                                                    }
                                                ?>
                                            </select>
                                            <select class="year" name="year" required="" style="padding: 6px; border: 1px solid #dcdcdc; border-radius: 5px;">
                                                <?php
                                                    echo "<option>- Year -</option>";
                                                    $y = 1940;
                                                    while($y <= 2021){
                                                        echo "<option value = '$y'>" .$y ."</option>";
                                                        $y++;
                                                    }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <input type="username" name="username"class="form-control" placeholder="Username *" required="" maxlength="20">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" name="password"class="form-control" placeholder="Password *" required="" maxlength="20">
                                        </div>
                                        <input type="submit" class="btnRegister" name="submit" value="Register">
                                    </div>
                                </div>
                            </div>
                        </form>   
            <center>   
                 <?php
                    session_start();
                    if (isset($_POST['submit'])) {
                        $firstname = $_POST['firstname'];
                        $lastname = $_POST['lastname'];
                        $email = $_POST['email'];
                        $address = $_POST['address'];
                        $day = $_POST['day'];
                        $month = $_POST['month'];
                        $year = $_POST['year'];
                        $contact = $_POST['contact'];
                        $username = $_POST['username'];
                        $password = $_POST['password'];
        
                        $pattern_name = "/^[\s|0-9]*$/";
                        if (preg_match($pattern_name, $firstname) == 0) {
                            $firstname_validation = "valid";
                        }
                        else
                            $lastname_validation = "invalid";

                        if (preg_match($pattern_name, $lastname) == 0) {
                            $lastname_validation = "valid"; 
                        }
                        else
                            $lastname_validation = "invalid";               
                
                
                        $pattern_email = "/^[a-zA-Z\d\-\_\.]+@[a-zA-Z]+\.[a-zA-Z\.]+$/";
                        if (preg_match($pattern_email, $email)) {
                            $email_validation = "valid";
                        }
                        else
                            $email_validation = "invalid";
                    
                        $pattern_address = "/^[\D\S]+$/";
                        if (preg_match($pattern_address, $address)) {
                            $address_validation = "valid";
                        }
                        else
                            $address_validation =  "invalid";

                        $pattern_month = "/^[a-zA-Z]{3,20}$/";
                        if (preg_match($pattern_month, $month)) {
                            $month_validation = "valid";
                        }      
                        else 
                            $month_validation = "invalid";

                        $pattern_day = "/^[0-9]{1,2}$/";
                        if (preg_match($pattern_day, $day)) {
                           $day_validation = "valid";
                        }      
                        else 
                           $day_validation = "invalid";

                        $pattern_year = "/^[0-9]{4}$/";
                        if (preg_match($pattern_year, $year)) {
                            $year_validation = "valid";
                        }      
                        else 
                            $year_validation = "invalid";

                        $pattern_contact = "/^[+]63[-][0-9]{3}[-][0-9]{4}[-][0-9]{3}$/";
                        if (preg_match($pattern_contact, $contact)) {
                            $contact_validation = "valid";  
                        }
                        else
                            $contact_validation = "invalid";

                
                        $pattern_username = "/^\w{5,20}$/";
                        if (preg_match($pattern_username, $username)) {
                            $username_validation = "valid";
                        }
                        else
                            $username_validation = "invalid";

                    
                        $pattern_password = "/^.{8,12}$/";
                        if (preg_match($pattern_password, $password)) {
                            $password_validation = "valid";
                        }
                        else
                            $password_validation = "invalid";

                        if($firstname_validation == "valid" && $lastname_validation == "valid" && $email_validation == "valid" && $contact_validation == "valid" && $username_validation == "valid" && $password_validation == "valid" && $address_validation == "valid" && $month_validation == "valid" && $day_validation == "valid" && $year_validation == "valid") {

                        $hashed_password=md5($password);

                        $_SESSION['firstname'] = $firstname;
                        $_SESSION['lastname'] = $lastname;
                        $_SESSION['email'] = $email;
                        $_SESSION['address'] = $address;
                        $_SESSION['day'] = $day;
                        $_SESSION['month'] = $month;
                        $_SESSION['year'] = $year;
                        $_SESSION['contact'] = $contact;
                        $_SESSION['username'] = $username;
                        $_SESSION['password'] = $hashed_password;

                        $insert_into_db = mysqli_query($con, "INSERT INTO user (firstname, lastname, email, contact, username, address, day, month, year, password) VALUES ('$_SESSION[firstname]', '$_SESSION[lastname]', '$_SESSION[email]', '$_SESSION[contact]', '$_SESSION[username]', '$_SESSION[address]', '$_SESSION[day]', '$_SESSION[month]', '$_SESSION[year]', '$_SESSION[password]')");
                        if(!$insert_into_db)
                            die("error saving into database");
                        else
                            header("location:profile.php");
                        }
                        else
                            echo "unable to save";

                    }
                ?>
                                        
        <script type="text/javascript"></script>
     </center>
</body>
</html>