<?php
	include("database.php");
	include("session.php");
	date_default_timezone_set('Asia/Manila');

	$user = $_SESSION['id'];

	if(isset($_POST['viewAppntBtn'])){
		$doctorId = $_POST['doctorId'];
	}

	if(isset($_POST['bookAppointment'])){
		$doctorId = $_POST['doctorId'];
		$schedId = $_POST['schedInfo'];
		$sql = "SELECT * FROM doctor_schedule WHERE id='$schedId'";
		$query = mysqli_query($con, $sql);
		while($row = mysqli_fetch_assoc($query)){
			$schedDate = $row['date'];
			$schedStartTime = $row['startTime'];
			$schedEndTime = $row['endTime'];
		}
		$p_name = $_SESSION['fullname'];
		$p_address = $_SESSION['address'];
		$p_contact = $_SESSION['contact'];
		$sql = "INSERT INTO appointments
		(patient_id,doctor_id,sched_id,date,startTime,endTime,stat,patient_name,patient_address,patient_contact) VALUES
		('$user','$doctorId','$schedId','$schedDate','$schedStartTime','$schedEndTime',0,'$p_name','$p_address','$p_contact')";
		if (mysqli_query($con, $sql)) {
			header('Location: appointment.php');
		}else{
			echo mysqli_error($con);
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>CLinEx</title>
	<link rel="icon" href="img/doctor.png">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<style type="text/css">
		* {
			padding: 0;
			margin: 0;
			box-sizing: border-box;
			font-family: arial, sans-serif;
		}
		.header {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 15px 30px;
			background: #300744;
			color: #fff; 
		}
		.u-name {
			font-size: 20px;
			padding-left: 17px;
		}
		.u-name b {
			color: #127b8e;
		}
		.header i {
			font-size: 30px;
			cursor: pointer;
			color: #fff;
		}
		.header i:hover {
			color: #127b8e;
		}
		.user-p {
			text-align: center;
			padding-left: 10px;
			padding-top: 25px;
		}
		.user-p img {
			width: 100px;
			border-radius: 50%;
		}
		.user-p h4 {
			color: #ccc;
			padding: 5px 0;

		}
		.side-bar {
			width: 250px;
			background: #480965;
			min-height: 100vh;
			transition: 500ms width;
		}
		.body {
			display: flex;
		}
		.section-1 {
			width: 100%;
			background: url("");
			background-size: cover;
			background-position: center;
			display: flex;
			flex-direction: column;
		}
		.side-bar ul {
			margin-top: 20px;
			list-style: none;
		}
		.side-bar ul li {
			font-size: 16px;
			padding: 15px 0px;
			padding-left: 20px;
			transition: 500ms background;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}
		.side-bar ul li:hover {
			background: #D085EC;
		}
		.side-bar ul li a {
			text-decoration: none;
			color: white;
			cursor: pointer;
			letter-spacing: 1px;
		}
		.side-bar ul li a i {
			display: inline-block;
			padding-right: 10px;
			font-size: 23px;
		}
		#navbtn {
			display: inline-block;
			margin-left: 70px;
			font-size: 20px;
			transition: 500ms color;
		}
		#checkbox {
			display: none;
		}
		#checkbox:checked ~ .body .side-bar {
			width: 60px;
		}
		#checkbox:checked ~ .body .side-bar .user-p{
			visibility: hidden;
		}
		#checkbox:checked ~ .body .side-bar a span{
			display: none;
		}
		
		.navi {
			width: 80px;
			padding-top: 30px;
		}
		h1 {
			text-align:center;
			font-size: 30px;
			color:   #004F13;
			margin-left: 0%;
			margin-top: 50px;
		}
		table {
			margin-left: auto;
			margin-right:auto;
			margin-bottom: 20px;

		}
		table, th, td {
			margin-left:auto;
			margin-right:auto;
			border:1px solid #d6d6d6;
			border-collapse: collapse;
			width:800px;
			text-align:center;
			background-color: #7D3C98;
		}
		td{
			background-color:  #D2B4DE;
		}
		select {
			width: 100%;
			height: 30px;
			color: black;
			border: 1px solid #c2c2c2;
		}

		input {
			width: 100px;
			height: 30px;
			color: black;
			border: 1px solid #c2c2c2;
			border-radius: 5px;
		}
		.edit{
			border: 1px solid white;
			padding: 8px 25px;
			color: #fff;
			background-color: #F3B40A;
			border-radius: 20px;
		}
		h4{
			margin-left: 10%;
		}
		.table-head th{
			color: #FFF;
			padding: 10px 5px;
		}
		.table-body td{
			font-size: 16px;
			font-weight: 500;
			padding: 10px 5px;
		}
		.bookApnt{
			background: #127b8e;
			color: #FFF;
			padding: 10px 5px;
			border: none;
			width: 100%
		}
	</style>	
</head>
<body>
	<input type="checkbox" id="checkbox">
	<header class="header">
		<h2 class="u-name">Clin <b>Ex</b>
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
	</header>
	<div class="body">
		<nav class="side-bar">
			<div class="user-p">
				<?php
					$select = mysqli_query($con, "SELECT * FROM user WHERE username = '$_SESSION[username]'");

					while ($count = mysqli_fetch_array($select)) {
				?>
				<h4><?php echo $count['firstname'] . " " .$count['lastname']; ?></h4>
				<?php
					}
				?>
			</div>
			<ul>
				<li>
					<a href="doctor.php">
						<i class="fa fa-user-md" aria-hidden="true"></i>
						<span>Doctor</span>
					</a>
				</li>
				<li>
					<a href="appointment.php">
						<i class="fa fa-calendar" aria-hidden="true"></i>
						<span>Appointment</span>
					</a>
				</li>
				<li>
					<a href="profile.php">
						<i class="fa fa-user" aria-hidden="true"></i>
						<span>Profile</span>
					</a>
				</li>
				<li>
					<a href="setting.php">
						<i class="fa fa-gear" aria-hidden="true"></i>
						<span>Setting</span>
					</a>
				</li>
				<li>
					<a href="logout.php">
						<i class="fa fa-sign-out" aria-hidden="true"></i>
						<span>Logout</span>
					</a>
				</li>
			</ul>
		</nav>
	<section class="section-1">
		<div id="content">
				<table>
					<h1>APPOINTMENT FORM</h1>
				</table>
		</div>
		<br>
		<br>
		<form method="post">
			<table> 
				<thead class="table-head">
					<th>ID</th>
					<th>NAME</th>
					<th>ADDRESS</th>
					<th>CONTACT</th>
				</thead>
				<tbody class="table-body">
					<?php
						$select = mysqli_query($con, "SELECT * FROM user WHERE username = '$_SESSION[username]' ");
						while($row = mysqli_fetch_array($select)){
							$user = $row['id'];
							echo "<tr>";
								echo "<td>" . $row['id']." " . "</td>";
								echo "<td>" . $row['firstname'] ." ". $row['lastname'] ." "."</td>";
								echo "<td>" . $row['address'] ." ". "</td>";
								echo "<td>" . $row['contact'] ." ". "</td>";
							echo "</tr>";
						}
					?>
				</tbody>
				
				
			</table>
		</form>
		<h1>SCHEDULE</h1>
		<br>
		<br>
		<br>
			<h4><?php echo date("W"); ?> WEEK OF THE <?php echo date("M"); ?></h4>
			<br>
			<br>

			<form method="post" action="add-appointment.php">
			    <table>
					<thead class="table-head">
						<th style="width: 5%">#</th>
			            <th style="width: 20%">DOCTOR</th>
			            <th style="width: 15%">SPECIALTY</th>
			            <th style="width: 40%">DAY&TIME</th>
			            <th style="width: 10%">ACTION</th>
					</thead>
					<tbody class="table-body">
						<input type="hidden" name="">
						<?php
							$sql = "SELECT * FROM registration WHERE id='$doctorId'";
							$query = mysqli_query($con, $sql);
							while($row = mysqli_fetch_assoc($query)){
								$doctorName = $row['firstname']." ". $row['lastname'];
								$specialty = $row['doctor'];
							}
							echo '
								<tr>
									<td>
										'.$doctorId.'
										<input type="hidden" name="doctorId" value="'.$doctorId.'">
									</td>
									<td>'.$doctorName.'</td>
									<td>'.$specialty.'</td>
									<td>
										<select name="schedInfo">
							';

							$sql = "SELECT * FROM doctor_schedule WHERE doctor_id='$doctorId' AND date > now()";
							$query = mysqli_query($con, $sql);
							while($row = mysqli_fetch_assoc($query)){
								$schedDate = $row['date'];
								$schedStartTime = $row['startTime'];
								$schedEndTime = $row['endTime'];
								$date = date('F d - l',strtotime($row['date']));
								$startTime = date('h:i a',strtotime($row['startTime']));
								$endTime = date('h:i a',strtotime($row['endTime']));
								$option = $date." - ".$startTime." to ".$endTime;
								echo '
											<option value='.$row['id'].'>'.$option.'</option>
								';
							}
							echo '
										</select>
									</td>
									<td>
										<button type="submit" class="bookApnt" name="bookAppointment">Book</button>
									</td>
								</tr>
							';
						?>

					</tbody>
					
			            
			    </table>
			</form>
			<center>
			<!-- 
		    if(isset($_POST['submit'])){
		        $time = $_POST['time'];
				$p_name = $_SESSION['fullname'];
				$p_address = $_SESSION['address'];
				$p_contact = $_SESSION['contact'];
		        $insert = mysqli_query($con, "INSERT INTO appointments (patient_id, doctor_id, tm, stat,patient_name,patient_address,patient_contact) VALUES ('$user', '$doctor', '$time', 0, '$p_name', '$p_address', '$p_contact')");
		        if(!$insert)
		            die("error saving appointment");
		        else
		            echo"Successfully Sent!";
		    }
		?> -->
	</center>
	</section>
</body>
</html>