<?php
 	include("session.php");
 	include("database.php");
?>

<!DOCTYPE html>
<html>
<head>
	<title>CLinEx</title>
	<link rel="icon" href="img/doctor.png">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
<style type="text/css">
* {
		padding: 0;
		margin: 0;
		box-sizing: border-box;
		font-family: arial, sans-serif;
		}
		.header {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 15px 30px;
			background: #300744;
			color: #fff; 
		}
		.u-name {
			font-size: 20px;
			padding-left: 17px;
		}
		.u-name b {
			color: #127b8e;
		}
		.header i {
			font-size: 30px;
			cursor: pointer;
			color: #fff;
		}
		.header i:hover {
			color: #127b8e;
		}
		.user-p {
			text-align: center;
			padding-left: 10px;
			padding-top: 25px;
		}
		.user-p img {
			width: 100px;
			border-radius: 50%;
		}
		.user-p h4 {
			color: #ccc;
			padding: 5px 0;

		}
		.side-bar {
			width: 250px;
			background: #480965;
			min-height: 100vh;
			transition: 500ms width;
		}
		.body {
			display: flex;
		}
		.section-1 {
			width: 100%;
			background: url("");
			background-size: cover;
			background-position: center;
			display: flex;
			flex-direction: column;
		}
		.side-bar ul {
			margin-top: 20px;
			list-style: none;
		}
		.side-bar ul li {
			font-size: 16px;
			padding: 15px 0px;
			padding-left: 20px;
			transition: 500ms background;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}
		.side-bar ul li:hover {
			background: #D085EC;
		}
		.side-bar ul li a {
			text-decoration: none;
			color: white;
			cursor: pointer;
			letter-spacing: 1px;
		}
		.side-bar ul li a i {
			display: inline-block;
			padding-right: 10px;
			font-size: 23px;
		}
		#navbtn {
			display: inline-block;
			margin-left: 70px;
			font-size: 20px;
			transition: 500ms color;
		}
		#checkbox {
			display: none;
		}
		#checkbox:checked ~ .body .side-bar {
			width: 60px;
		}
		#checkbox:checked ~ .body .side-bar .user-p{
			visibility: hidden;
		}
		#checkbox:checked ~ .body .side-bar a span{
			display: none;
		}
		
		.navi {
			width: 80px;
			padding-top: 30px;
		}
		h1 {
			text-align:center;
			font-size: 30px;
			color:   #004F13;
			margin-left: -35px;
			margin-top: 50px;
		}
		table {
			margin-left: auto;
			margin-right:auto;
			margin-bottom: 20px;

		}
		#prod_id {
			text-align:center;
			color:white;
			background-color: orange;
		}
		select {
			width: 296px;
			height: 35px;
			color: black;
			border: 1px solid #c2c2c2;
		}

		input {
			width: 400px;
			height: 40px;
			color: black;
			border: 1px solid #c2c2c2;
			margin-left: 15px;
		}
		table, th, td {
			margin-left:auto;
			margin-right:auto;
			border:1px solid #d6d6d6;
			border-collapse: collapse;
			width:800px;
			text-align:center;
			background-color: #7D3C98;
		}
		td{
			background-color:  #D2B4DE;
		}
		#prod_id {
			text-align:center;
			color:white;
			background-color: orange;
		}
		select {
			color: black;
			border: 1px solid #c2c2c2;
		}

		input {
			color: black;
			border: 1px solid #c2c2c2;
		}
		.edit{
			border: 1px solid white;
			padding: 8px 25px;
			color: #fff;
			background-color: #F3B40A;
			border-radius: 20px;
		}
		.table-head th{
			color: #FFF;
			padding: 10px 5px;
		}
		.table-body td{
			font-size: 16px;
			font-weight: 500;
			padding: 10px 5px;
		}
		.btnViewDoctor{
			font-size: 15px;
			background-color: #127b8e;
			border: none;
			color: #FFF;
			padding: 10px;
		}
</style>	
</head>
<body>
	<input type="checkbox" id="checkbox">
	<header class="header">
		<h2 class="u-name">Clin <b>Ex</b>
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
	</header>
	<div class="body">
		<nav class="side-bar">
			<div class="user-p">
				<?php
					$select = mysqli_query($con, "SELECT * FROM user WHERE username = '$_SESSION[username]'");

					while ($count = mysqli_fetch_array($select)) {
				?>
				<h4><?php echo $count['firstname'] . " " .$count['lastname']; ?></h4>
				<?php
					}
				?>
			</div>
			<ul>
				<li>
					<a href="doctor.php">
						<i class="fa fa-user-md" aria-hidden="true"></i>
						<span>Doctor</span>
					</a>
				</li>
				<li>
					<a href="appointment.php">
						<i class="fa fa-calendar" aria-hidden="true"></i>
						<span>Appointment</span>
					</a>
				</li>
				<li>
					<a href="profile.php">
						<i class="fa fa-user" aria-hidden="true"></i>
						<span>Profile</span>
					</a>
				</li>
				<li>
					<a href="setting.php">
						<i class="fa fa-gear" aria-hidden="true"></i>
						<span>Setting</span>
					</a>
				</li>
				<li>
					<a href="logout.php">
						<i class="fa fa-sign-out" aria-hidden="true"></i>
						<span>Logout</span>
					</a>
				</li>
			</ul>
		</nav>
	<section class="section-1">
		<div id="content">
				<table>
					<h1>DOCTOR SCHEDULE</h1>
				</table>
		</div>
		<br>
		<br>
		
		<table >
			<thead class="table-head">
				<th>ID</th>
				<th>DOCTOR</th>
				<th>SPECIALIZATION</th>
				<th>CONTACT</th>
				<th>Action</th>
			</thead>
			<tbody class="table-body">
				<?php
					$select = mysqli_query($con, "SELECT * FROM doctor_schedule GROUP BY doctor_id");
					while($row=mysqli_fetch_array($select)){
						$doctor = $row['doctor_id'];

						$selectdoctor = mysqli_query($con, "SELECT * FROM registration WHERE id = '$doctor'");
						while($rows = mysqli_fetch_array($selectdoctor)){
							echo "<tr>";
							echo "<td>" .$doctor = $rows['id']."</td>";
							echo "<td>".$rows['firstname']." ".$rows['lastname']."</td>";
							echo "<td>".$rows['doctor']."</td>";
							echo "<td>".$rows['contact']."</td>";
							echo '<td>
									<form action="add-appointment.php" method="POST">
										<input type="hidden" name="doctorId" value="'.$rows['id'].'">
										<button type="submit" class="btnViewDoctor" name="viewAppntBtn">View Schedule</button>
									</form>
								</td>
								<tr>';
						}
						
					}
				?>
			</tbody>
			
		</table>
	</section>

</body>
</html>