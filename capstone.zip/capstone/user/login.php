<?php
    include 'database.php';
    ob_start();
?>

<html>
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <style>
        .register{
            background: -webkit-linear-gradient(left,#653d84, #332042);
            padding: 3%;
            height: 100%;
            max-width: 200%;
        }
        .register-left{
            text-align: center;
            color: #fff;
            margin-top: 10%;
        }
        .register-left input{
            border: none;
            border-radius: 1.5rem;
            padding: 2%;
            width: 60%;
            background: #f8f9fa;
            font-weight: bold;
            color: #383d41;
            margin-top: 40%;
            margin-bottom: 3%;
            cursor: pointer;
            font-family: 
        }
        .register-right{
            background: #f8f9fa;
            border-top-left-radius: 10% 50%;
            border-bottom-left-radius: 10% 50%;
        }
        .register-left img{
            margin-top: 15%;
            margin-bottom: 5%;
            width: 50%;
            -webkit-animation: mover 2s infinite  alternate;
            animation: mover 1s infinite  alternate;
        }
        @-webkit-keyframes mover {
            0% { transform: translateY(0); }
            100% { transform: translateY(-20px); }
        }
        @keyframes mover {
            0% { transform: translateY(0); }
            100% { transform: translateY(-20px); }
        }
        .register-left p{
            font-weight: lighter;
            padding: 12%;
            margin-top: -9%;
        }
        .register .register-form{
            padding: 5%;
            margin-top: 15%;
            margin-left: 25%;
        }
        .btnRegister{
            float: right;
            margin-top: 10%;
            border: none;
            border-radius: 1.5rem;
            padding: 2%;
            background: #653d84;
            color: #fff;
            font-weight: 600;
            width: 50%;
            cursor: pointer;
        }
        .register-heading{
            text-align: center;
            margin-top: 10%;
            margin-bottom: -15%;
            color: #495057;
            font-family: tahoma;
            font-weight: bold;
            font-size: 40px;
        }
</style>
</head>
<body>
    <div class="container register">
                <div class="row">
                    <div class="col-md-3 register-left">
                        <img src="https://i.pinimg.com/originals/e3/7e/14/e37e14e207070d62cfc4d0b050f3ad91.png" alt="">
                        <h3>Welcome to Clinex</h3>
                        <p>Enter your personal details and start journey with us!</p>
                        <a href="index.php">
                            <input type="submit" name="register" value="Sign up"><br>
                        </a>
                    </div>
                    <div class="col-md-9 register-right">
                        <div class="tab-pane fade show active" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                            <form method="POST">
                                <h3 class="register-heading">log in</h3>
                                <div class="row register-form">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="username" name="username"class="form-control" placeholder="Username *" required="" maxlength="20">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" name="password"class="form-control" placeholder="Password *" required="" maxlength="12">
                                        </div>
                                        <p>
                                            <div class="g-recaptcha" data-sitekey="6Le-q0IdAAAAABYQZ67jKNej5_bGDJnh2Oychrkh"></div>
                                        </p>
                                        <input type="submit" class="btnRegister" name="submit" value="Log in">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                <center>
                    <?php
                        session_start();
                        if (isset($_POST['submit']) && $_POST['g-recaptcha-response'] !="") {
                            $username = $_POST['username'];
                            $password = $_POST['password'];
                            //captcha
                            $secretKey="6Le-q0IdAAAAADW6D6uIOeSo6d_10EzsI2sPqZG5";
                            $responseKey= $_POST['g-recaptcha-response'];
                            $userIP = $_SERVER['REMOTE_ADDR'];
                            
                            $url= "https://www.google.com/recaptcha/api/siteverify?secret=$secretKey$response=$responseKey&remoteip=$userIP";
                            $response = file_get_contents($url);
                            echo $response;

                            $password = md5($password);

                            $select = mysqli_query($con, "SELECT * FROM user WHERE username = '$username' AND password = '$password'");
                            //query, connection
                            while ($result = mysqli_fetch_array($select)){
                                $_SESSION['username'] = $result['username'];
                                $_SESSION['password'] = $result['password'];
                                $_SESSION['fullname'] = $result['firstname']." ".$result['lastname'];
                                $_SESSION['address'] = $result['address'];
                                $_SESSION['contact'] = $result['contact'];
                                $_SESSION['id'] = $result['id'];
                            }
                            
                            $count = mysqli_num_rows($select);
                            //mysqli_query
                            if($count==1)
                               header("location:profile.php");
                            else
                                echo "Account doesn't exist";
                        }
                    ?>
            </center>
    <script type="text/javascript"></script>
</body>
</html>