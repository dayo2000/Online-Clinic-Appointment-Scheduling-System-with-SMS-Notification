<?php
	include("session.php");
	include("database.php");
?>

<!DOCTYPE html>
<html>
<head>
	<title>CLinEx</title>
	<link rel="icon" href="doctor.png">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
* {
		padding: 0;
		margin: 0;
		box-sizing: border-box;
		font-family: arial, sans-serif;
		}
		.header {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 15px 30px;
			background: #23242b;
			color: #fff;
		}
		.u-name {
			font-size: 20px;
			padding-left: 17px;
		}
		.u-name b {
			color: #127b8e;
		}
		.header i {
			font-size: 30px;
			cursor: pointer;
			color: #fff;
		}
		.header i:hover {
			color: #127b8e;
		}
		.header h3{
			font-size: 20px;
		}
		.user-p {
			text-align: center;
			padding-left: 10px;
			padding-top: 25px;
		}
		.user-p img {
			width: 100px;
			border-radius: 50%;
		}
		.user-p h4 {
			color: #ccc;
			padding: 5px 0;

		}
		.side-bar {
			width: 250px;
			background: #262931;
			min-height: 100vh;
			transition: 500ms width;
		}
		.body {
			display: flex;
		}
		.section-1 {
			width: 100%;
			background: url("");
			background-size: cover;
			background-position: center;
			display: flex;
			flex-direction: column;
		}
		.section-1 h1 {
			color: #fff;
			font-size: 60px;
		}
		.section-1 p {
			color: #127b8e;
			font-size: 20px;
			background: #fff;
			padding: 7px;
			border-radius: 5px;
		}
		.side-bar ul {
			margin-top: 20px;
			list-style: none;
		}
		.side-bar ul li {
			font-size: 16px;
			padding: 15px 0px;
			padding-left: 20px;
			transition: 500ms background;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}
		.side-bar ul li:hover {
			background: #127b8e;
		}
		.side-bar ul li a {
			text-decoration: none;
			color: #eee;
			cursor: pointer;
			letter-spacing: 1px;
		}
		.side-bar ul li a i {
			display: inline-block;
			padding-right: 10px;
			font-size: 23px;
		}
		#navbtn {
			display: inline-block;
			margin-left: 70px;
			font-size: 20px;
			transition: 500ms color;
		}
		#checkbox {
			display: none;
		}
		#checkbox:checked ~ .body .side-bar {
			width: 60px;
		}
		#checkbox:checked ~ .body .side-bar .user-p{
			visibility: hidden;
		}
		#checkbox:checked ~ .body .side-bar a span{
			display: none;
		}
		h5{
			font-size: 30px;
			color:   #004F13;

		}
		table {
			margin-left: auto;
			margin-right:auto;
			margin-bottom: 20px;

		}
		
		table, th, td {
			margin-left:auto;
			margin-right:auto;
			border:1px solid #d6d6d6;
			border-collapse: collapse;
			width:800px;
			text-align:center;
		}
		td{
			width: 10px;
		}
		.accept{
			border: none;
			padding: 10px 25px;
			color: #fff;
			background-color: #27AE60 ;
			border-radius: 5px;
		}
		.decline{
			border: none;
			padding: 10px 25px;
			color: #fff;
			background-color: #F12525 ;
			border-radius: 5px;
			margin-bottom: 30px;
		}
</style>	
</head>
<body>
	<input type="checkbox" id="checkbox">
	<header class="header">
		<h2 class="u-name">Clin <b>Ex</b>
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
		<h3>Appointment</h3>
		</h2>
	</header>
	<div class="body">
		<nav class="side-bar">
			<div class="user-p">
				<?php
					$select = mysqli_query($con, "SELECT * FROM registration WHERE username = '$_SESSION[username]'");

					while ($count = mysqli_fetch_array($select)) {
				?>	
				<h4><?php echo "Dra. " .$count['firstname'] .$count['lastname']; ?></h4>
				<?php
					}
				?>
			</div>
			<ul>
				<li>
					<a href="dashboard.php">
						<i class="fa fa-dashboard" aria-hidden="true"></i>
						<span>Dashboard</span>
					</a>
				</li>
				<li>
					<a href="doctor.php">
						<i class="fa fa-user-md" aria-hidden="true"></i>
						<span>Doctor</span>
					</a>
				</li>
				<li>
					<a href="patient.php">
						<i class="fa fa-stethoscope" aria-hidden="true"></i>
						<span>Patient</span>
					</a>
				</li>
				<li>
					<a href="appointment.php">
						<i class="fa fa-calendar" aria-hidden="true"></i>
						<span>Appointment</span>
					</a>
				</li>
				<li>
					<a href="record.php">
						<i class="	fa fa-address-book" aria-hidden="true"></i>
						<span>Record</span>
					</a>
				</li>
				<li>
					<a href="logout.php">
						<i class="fa fa-sign-out" aria-hidden="true"></i>
						<span>Logout</span>
					</a>
				</li>
			</ul>
		</nav>
		<section class="section-1">
			<div>
				<center>
					<br>
					<br>
					<br>
					<h5>ACCEPT/DECLINE APPOINTMENT</h5>
					<br>
					<br>
					 <?php
				        $select = mysqli_query($con, "SELECT * FROM appointments WHERE doctor_id = doctor_id AND stat=0");
				        while($row = mysqli_fetch_array($select)){
				            $patient = $row['patient_id'];
				            $appointmentID = $row['id'];
				            
				            echo "<p style='color: #000'><b>APPOINTMENT ID: </b>" . $appointmentID . "</p>";
				            echo "<p>". date('F d - l',strtotime($row['date'])). "</p>";
							echo "<p>". date('h	:i A',strtotime($row['startTime'])) . " " . date('h:i A',strtotime($row['endTime'])) . "</p>";
							
				            //fetch name
				            $selectdoctor = mysqli_query($con, "SELECT * FROM user WHERE id = '$patient'");
				            while($rows = mysqli_fetch_array($selectdoctor)){
				               
				                echo "<p>" . $rows['firstname'] . " ".$rows['lastname'] ."</p>";
				                echo "<p>" . $rows['address'] . "</p>";
				                echo "<p>" . $rows['contact'] . "</p>";
				            }
				            //end fetch name
				        ?>

				        <a href="appointment.php?accept=<?php echo $appointmentID; ?>"><button class="accept">ACCEPT</button></a>
				        <a href="appointment.php?deny=<?php echo $appointmentID; ?>"><button class="decline">DENY</button></a>
				        
				        <?php
				        }
				    ?>


				<?php

				if(isset($_GET['accept'])){
				    $id = $_GET['accept'];
				    $update = mysqli_query($con, "UPDATE appointments SET stat = 1 WHERE id = $id");
				    if(!$update)
				        die("Error");
				    else{
				       	include 'sms.php';
				    }  

				}

				if(isset($_GET['deny'])){
				    $id = $_GET['deny'];
				    $update = mysqli_query($con, "UPDATE appointments SET stat = 2 WHERE id = $id");
				    if(!$update)
				        die("Error");
				    else{
				        echo "<script>alert('denied');window.location.href='appointment.php'</script>";
				    }   
				}

				?>
				</center>		
			</div>
		</section>
	</div>

</body>
</html>