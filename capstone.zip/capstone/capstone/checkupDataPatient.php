<?php

include ('session.php');
include ("database.php");

$id = $_GET['id'];

$sql = "SELECT * FROM user WHERE id='$id'";
$result = mysqli_query($con, $sql);

if (mysqli_num_rows($result) > 0) {
  while($row = mysqli_fetch_assoc($result)) {
    $array = array(
      'fullname' => $row['firstname']. " ". $row['lastname'],
      'address' =>  $row['address'],
      'contact' => $row['contact'],
    );
  }
  echo json_encode($array);
}

?>