<?php
	include("session.php");
	include("database.php");
    $doctorId = $_SESSION['id'];
	$errormsg = '';

    if(isset($_POST['submitSched'])){
        /** PATIENT */
        $user = $_POST['name'];
        $p_name= $_POST['patientFullname'];
        $p_address = $_POST['patientAddress'];
        $p_contact = $_POST['patientContact'];

        /*** sched */
        $schedId = $_POST['schedId'];
        $schedDate = $_POST['date'];
        $schedStartTime = $_POST['startTimeSched'];
        $schedEndTime = $_POST['endTimeSched'];

		
		$sql = "SELECT * FROM appointments WHERE date='$schedDate' AND patient_id='$user'";
		$result = mysqli_query($con, $sql);

		if (mysqli_num_rows($result) > 0) {
			$errormsg = "The patient already have a schedule on this date. Please choose another";
		}else{
            $sql = "INSERT INTO appointments
            (patient_id,doctor_id,sched_id,date,startTime,endTime,stat,patient_name,patient_address,patient_contact) VALUES
            ('$user','$doctorId','$schedId','$schedDate','$schedStartTime','$schedEndTime',1,'$p_name','$p_address','$p_contact')";
			if (mysqli_query($con, $sql)) {
				header("Location:patient.php");
			}else{
                echo mysqli_error($con);
            }
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>CLinEx</title>
	<link rel="icon" href="doctor.png">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap5.min.css">
	
	<style type="text/css">
		* {
			padding: 0;
			margin: 0;
			box-sizing: border-box;
			font-family: arial, sans-serif;
		}
		.header {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 15px 30px;
			background: #23242b;
			color: #fff;
		}
		.u-name {
			font-size: 20px;
			padding-left: 17px;
		}
		.u-name b {
			color: #127b8e;
		}
		.header i {
			font-size: 30px;
			cursor: pointer;
			color: #fff;
		}
		.header i:hover {
			color: #127b8e;
		}
		.header h3{
			font-size: 20px;
		}
		.user-p {
			text-align: center;
			padding-left: 10px;
			padding-top: 25px;
		}
		.user-p img {
			width: 100px;
			border-radius: 50%;
		}
		.user-p h4 {
			color: #ccc;
			padding: 5px 0;

		}
		.side-bar {
			width: 250px;
			background: #262931;
			min-height: 100vh;
			transition: 500ms width;
		}
		.body {
			display: flex;
		}
		.section-1 {
			width: 100%;
			background: url("");
			background-size: cover;
			background-position: center;
			display: flex;
			flex-direction: column;
            align-self: center;
            align-items: center;
		}
		.side-bar ul {
			margin-top: 20px;
			list-style: none;
		}
		.side-bar ul li {
			font-size: 16px;
			padding: 15px 0px;
			padding-left: 20px;
			transition: 500ms background;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}
		.side-bar ul li:hover {
			background: #127b8e;
		}
		.side-bar ul li a {
			text-decoration: none;
			color: #eee;
			cursor: pointer;
			letter-spacing: 1px;
		}
		.side-bar ul li a i {
			display: inline-block;
			padding-right: 10px;
			font-size: 23px;
		}
		#navbtn {
			display: inline-block;
			margin-left: 70px;
			font-size: 20px;
			transition: 500ms color;
		}
		#checkbox {
			display: none;
		}
		#checkbox:checked ~ .body .side-bar {
			width: 60px;
		}
		#checkbox:checked ~ .body .side-bar .user-p{
			visibility: hidden;
		}
		#checkbox:checked ~ .body .side-bar a span{
			display: none;
		}
		.navi {
			width: 80px;
			padding-top: 30px;
		}
		h1 {
			text-align:center;
			font-size: 30px;
			color:   #004F13;
			margin-left: -5px;
			margin-top: 50px;
		}
		table {
			margin-left: auto;
			margin-right:auto;
			margin-bottom: 20px;

		}
		select {
			height: 32px;
			width: 100%;
			color: black;
			border: 1px solid #c2c2c2;
			border-radius: 5px;
		}

		input {
			color: black;
			border: 1px solid #404040;
			border-radius: 5px;
			padding: 10px;
		}
		.tic{
			margin-left:auto;
			margin-right:auto;
			border:2px solid #1F618D;
			border-collapse: collapse;
			width:500px;
			text-align:center;
		}
		.crudButtons-div{
			display: block;
			text-align: center;
    		margin: 30px auto;
		}
		.crudButton{
			font-size:20px;
			color: white;
			border: none;
			text-decoration: none;
			border-radius: 5px;
			padding: 10px;
			display: inline;
		}
		.inputTable td{
			padding: 10px;
		}
		.inputTable input[type="submit"]{
			background: #127b8e;
			color: #fff;
			padding: 10px;
			margin-right: 10px;
			text-decoration: none;
			border: none;
		}
		button[type=submit]{
			background: #1b7b8e;
			color: #FFF;
			border: none;
			width: 100%;
			padding: 7px;
		}
		.errorMessage{
			color: red;
			font-size: 14px;
			margin-bottom: 10px;
		}
		.schedSuccess{
			color: green;
			font-size: 20px;
			margin: 10px auto;
		}
	</style>
</head>
<body>
	<input type="checkbox" id="checkbox">
	<header class="header">
		<h2 class="u-name">Clin <b>Ex</b>
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
			<h3>Patient</h3>
		</h2>
	</header>
	<div class="body">
		<nav class="side-bar">
			<div class="user-p">
				<?php
					$select = mysqli_query($con, "SELECT * FROM registration WHERE username = '$_SESSION[username]'");

					while ($count = mysqli_fetch_array($select)) {
				?>	
				<h4><?php echo "Dra. " .$count['firstname'] .$count['lastname']; ?></h4>
				<?php
					}
				?>
			</div>
			<ul>
				<li>
					<a href="dashboard.php">
						<i class="fa fa-dashboard" aria-hidden="true"></i>
						<span>Dashboard</span>
					</a>
				</li>
				<li>
					<a href="doctor.php">
						<i class="fa fa-user-md" aria-hidden="true"></i>
						<span>Doctor</span>
					</a>
				</li>
				<li>
					<a href="patient.php">
						<i class="fa fa-stethoscope" aria-hidden="true"></i>
						<span>Patient</span>
					</a>
				</li>
				<li>
					<a href="appointment.php">
						<i class="fa fa-calendar" aria-hidden="true"></i>
						<span>Appointment</span>
					</a>
				</li>
				<li>
					<a href="record.php">
						<i class="	fa fa-address-book" aria-hidden="true"></i>
						<span>Record</span>
					</a>
				</li>
				<li>
					<a href="logout.php">
						<i class="fa fa-sign-out" aria-hidden="true"></i>
						<span>Logout</span>
					</a>
				</li>
			</ul>
		</nav>
		<section class="section-1">
			<h1>Create Check Up</h3>
            <div class="check-up" style="width: 500px;text-align: center;align-self: center;margin-top: 2%">
                <form action="checkup.php" method="post">
                <div style="display: flex;width: 100%;margin-bottom: 10px;">
						<div style="display: inline-flex; width: 50%;">
							<p style="margin: auto 0;">Name of Patient: </p>
						</div>
						<div style="display: inline-flex; width: 50%">
							<select name="name" id="name" style="width: 100%;height: 40px;">
								<?php
									$sql = "SELECT * FROM user";
									$result = mysqli_query($con, $sql);

									if (mysqli_num_rows($result) > 0) {
										while($row = mysqli_fetch_assoc($result)) {
											echo '<option id="'.$row['id'].'" value="'.$row['id'].'">'.$row['firstname']." ".$row['lastnamee'].'</option>';
										}
									}
								?>
								
							</select>
						</div>
					</div>
                    <input type="hidden" name="patientFullname" id="patientFullname">
					<div style="display: flex;width: 100%;margin-bottom: 10px;">
						<div style="display: inline-flex; width: 50%;">
							<p style="margin: auto 0;">Address: </p>
						</div>
						<div style="display: inline-flex; width: 50%">
						<input type="text" name="patientAddress" id="patientAddress" style="width: 100%" readonly>
						</div>
					</div>
					<div style="display: flex;width: 100%;margin-bottom: 10px;">
						<div style="display: inline-flex; width: 50%;">
							<p style="margin: auto 0;">Contact: </p>
						</div>
						<div style="display: inline-flex; width: 50%">
							<input type="text" name="patientContact" id="patientContact" style="width: 100%" readonly>
						</div>
					</div>
                    <div style="display: flex;width: 100%;margin-bottom: 10px;">
						<div style="display: inline-flex; width: 50%;">
							<p style="margin: auto 0;">Date of Schedule: </p>
						</div>
						<div style="display: inline-flex; width: 50%">
							<select name="date" id="date" style="width: 100%;">
								<?php
									$sql = "SELECT * FROM doctor_schedule WHERE doctor_id='$doctorId' AND DATE >= now()";
									$result = mysqli_query($con, $sql);

									if (mysqli_num_rows($result) > 0) {
										while($row = mysqli_fetch_assoc($result)) {
											echo '<option id="'.$row['id'].'" value="'.$row['date'].'">'.$row['date'].'</option>';
										}
									}
								?>
							</select>
						</div>
					</div>
					<div style="display: flex;width: 100%;margin-bottom: 10px;">
						<div style="display: inline-flex; width: 50%;">
							<p style="margin: auto 0;">Start Time: </p>
						</div>
						<div style="display: inline-flex; width: 50%">
						<input type="time" name="startTimeSched" id="startTimeSched" style="width: 100%" readonly>
						</div>
					</div>
					<div style="display: flex;width: 100%;margin-bottom: 10px;">
						<div style="display: inline-flex; width: 50%;">
							<p style="margin: auto 0;">Start Time of Schedule: </p>
						</div>
						<div style="display: inline-flex; width: 50%">
							<input type="time" name="endTimeSched" id="endTimeSched" style="width: 100%" readonly>
						</div>
					</div>
                    <input type="hidden" name="schedId" id="schedId" value="">
					<p class="errorMessage"><?php echo $errormsg ?></p>
					<button type="submit" name="submitSched">Create</button>
                </form>
            </div>
			
		</section>
	</div>

	<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script>
		$('#name').ready(function() {
			var id = $(this).find('option:selected').attr('id');
			$.ajax({
				type: "GET",
				url: "checkupDataPatient.php?id="+id,
				async: false,
				success: function(response) {
					var returnedData = JSON.parse(response);
					$('#patientFullname').val(returnedData.fullname);
					$('#patientAddress').val(returnedData.address);
					$('#patientContact').val(returnedData.contact);
				}
			});
		});
		$('#name').on('change', function() {
			var id = $(this).find('option:selected').attr('id');
			$.ajax({
				type: "GET",
				url: "checkupDataPatient.php?id="+id,
				async: false,
				success: function(response) {
					var returnedData = JSON.parse(response);
					$('#patientFullname').val(returnedData.fullname);
					$('#patientAddress').val(returnedData.address);
					$('#patientContact').val(returnedData.contact);
				}
			});
		});
        $('#date').ready(function() {
			var id = $(this).find('option:selected').attr('id');
			$.ajax({
				type: "GET",
				url: "editData.php?id="+id,
				async: false,
				success: function(response) {
					var returnedData = JSON.parse(response);
					$('#doctorId').val(returnedData.doctorId);
					$('#schedId').val(returnedData.id);
					$('#startTimeSched').val(returnedData.start);
					$('#endTimeSched').val(returnedData.end);
				}
			});
		});
		$('#date').on('change', function() {
			var id = $(this).find('option:selected').attr('id');
			$.ajax({
				type: "GET",
				url: "editData.php?id="+id,
				async: false,
				success: function(response) {
					var returnedData = JSON.parse(response);
					$('#doctorId').val(returnedData.doctorId);
					$('#schedId').val(returnedData.id);
					$('#startTimeSched').val(returnedData.start);
					$('#endTimeSched').val(returnedData.end);
				}
			});
		});
	</script>
</body>
</html>
