<?php
	include ("session.php");
	include ("database.php");

	$errormsg = '';
	$schedSuccess = '';

	if(isset($_POST['submitSched'])){
		$sched_doctorId = $_POST['doctorId'];
		$sched_date = $_POST['dateSched'];
		$sched_startTime = $_POST['startTimeSched'];
		$sched_endTime = $_POST['endTimeSched'];

		$sql = "SELECT * FROM doctor_schedule WHERE doctor_id='$sched_doctorId' AND date='$sched_date'";
		$result = mysqli_query($con, $sql);

		if (mysqli_num_rows($result) > 0) {
			$errormsg = "You already have a schedule on this date. Please choose another";
		}else{
			$sql = "INSERT INTO doctor_schedule (doctor_id,date,startTime,endTime)
			VALUES ('$sched_doctorId', '$sched_date', '$sched_startTime', '$sched_endTime')";

			if (mysqli_query($con, $sql)) {
				$schedSuccess = "New schedule created successfully";
			}
		}

		
	}
	
?>

<!DOCTYPE html>
<html>
<head>
	<title>CLinEx</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" href="doctor.png">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<style type="text/css">
		* {
			padding: 0;
			margin: 0;
			box-sizing: border-box;
			font-family: arial, sans-serif;
		}
		.header {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 15px 30px;
			background: #23242b;
			color: #fff;
		}
		.u-name {
			font-size: 20px;
			padding-left: 17px;
		}
		.u-name b {
			color: #127b8e;
		}
		.header i {
			font-size: 30px;
			cursor: pointer;
			color: #fff;
		}
		.header i:hover {
			color: #127b8e;
		}
		.header h3{
			font-size: 20px;
		}
		.user-p {
			text-align: center;
			padding-left: 10px;
			padding-top: 25px;
		}
		.user-p img {
			width: 100px;
			border-radius: 50%;
		}
		.user-p h4 {
			color: #ccc;
			padding: 5px 0;

		}
		.side-bar {
			width: 250px;
			background: #262931;
			min-height: 100vh;
			transition: 500ms width;
		}
		.body {
			display: flex;
		}
		.section-1 {
			width: 100%;
			background: url("");
			background-size: cover;
			background-position: center;
			display: flex;
			flex-direction: column;
		}
		.side-bar ul {
			margin-top: 20px;
			list-style: none;
		}
		.side-bar ul li {
			font-size: 16px;
			padding: 15px 0px;
			padding-left: 20px;
			transition: 500ms background;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}
		.side-bar ul li:hover {
			background: #127b8e;
		}
		.side-bar ul li a {
			text-decoration: none;
			color: #eee;
			cursor: pointer;
			letter-spacing: 1px;
		}
		.side-bar ul li a i {
			display: inline-block;
			padding-right: 10px;
			font-size: 23px;
		}
		#navbtn {
			display: inline-block;
			margin-left: 70px;
			font-size: 20px;
			transition: 500ms color;
		}
		#checkbox {
			display: none;
		}
		#checkbox:checked ~ .body .side-bar {
			width: 60px;
		}
		#checkbox:checked ~ .body .side-bar .user-p{
			visibility: hidden;
		}
		#checkbox:checked ~ .body .side-bar a span{
			display: none;
		}
		.navi {
			width: 80px;
			padding-top: 30px;
		}
		h1 {
			text-align:center;
			font-size: 30px;
			color:   #004F13;
			margin-left: -5px;
			margin-top: 50px;
		}
		table {
			margin-left: auto;
			margin-right:auto;
			margin-bottom: 20px;

		}
		select {
			height: 32px;
			width: 100%;
			color: black;
			border: 1px solid #c2c2c2;
			border-radius: 5px;
		}

		input {
			color: black;
			border: 1px solid #404040;
			border-radius: 5px;
			padding: 10px;
		}
		.tic{
			margin-left:auto;
			margin-right:auto;
			border:2px solid #1F618D;
			border-collapse: collapse;
			width:500px;
			text-align:center;
		}
		.crudButtons-div{
			display: block;
			text-align: center;
    		margin: 30px auto;
		}
		.crudButton{
			font-size:20px;
			color: white;
			border: none;
			text-decoration: none;
			border-radius: 5px;
			padding: 10px;
			display: inline;
		}
		.inputTable td{
			padding: 10px;
		}
		.inputTable input[type="submit"]{
			background: #127b8e;
			color: #fff;
			padding: 10px;
			margin-right: 10px;
			text-decoration: none;
			border: none;
		}
		button[type=submit]{
			background: #1b7b8e;
			color: #FFF;
			border: none;
			width: 100%;
			padding: 7px;
		}
		.errorMessage{
			color: red;
			font-size: 14px;
			margin-bottom: 10px;
		}
		.schedSuccess{
			color: green;
			font-size: 20px;
			margin: 10px auto;
		}
	</style>	
</head>
<body>
	<input type="checkbox" id="checkbox">
	<header class="header">
		<h2 class="u-name">Clin <b>Ex</b>
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
		<h3>Doctor</h3>
		</h2>
	</header>
	<div class="body">
		<nav class="side-bar">
			<div class="user-p">
				<?php
					$select = mysqli_query($con, "SELECT * FROM registration WHERE username = '$_SESSION[username]'");

					while ($count = mysqli_fetch_array($select)) {
				?>	
				<h4><?php echo "Dra. " .$count['firstname'] .$count['lastname']; ?></h4>
				<?php
					}
				?>
			</div>
			<ul>
				<li>
					<a href="dashboard.php">
						<i class="fa fa-dashboard" aria-hidden="true"></i>
						<span>Dashboard</span>
					</a>
				</li>
				<li>
					<a href="doctor.php">
						<i class="fa fa-user-md" aria-hidden="true"></i>
						<span>Doctor</span>
					</a>
				</li>
				<li>
					<a href="patient.php">
						<i class="fa fa-stethoscope" aria-hidden="true"></i>
						<span>Patient</span>
					</a>
				</li>
				<li>
					<a href="appointment.php">
						<i class="fa fa-calendar" aria-hidden="true"></i>
						<span>Appointment</span>
					</a>
				</li>
				<li>
					<a href="record.php">
						<i class="	fa fa-address-book" aria-hidden="true"></i>
						<span>Record</span>
					</a>
				</li>
				<li>
					<a href="logout.php">
						<i class="fa fa-sign-out" aria-hidden="true"></i>
						<span>Logout</span>
					</a>
				</li>
			</ul>
		</nav>
		<section class="section-1">
			<div>
				<h1>CREATE SCHEDULE</h1>
				<div class="crudButtons-div">
					<a href="view.php" class="fa fa-eye view crudButton" style="background-color: #1b7b8e;">View</a>
					<a href="edit.php" class="fa fa-edit edit crudButton" style="background-color: #18871E;">Update</a>
					<a href="delete.php" class="fa fa-trash-o delete crudButton" style="background-color: #c30000;">Delete</a>
				</div>
			</div>
			<?php
				$select = mysqli_query($con, "SELECT * FROM registration WHERE username = '$_SESSION[username]'");
				while($row = mysqli_fetch_assoc($select)){
					$doctorId = $row['id'];
					$doctorName = $row['firstname']." ". $row['lastname'];
					$specialization = $row['doctor'];
					$contact = $row['contact'];
				}
			?>
			<div style="width: 500px;text-align: center;align-self: center;display:inline-flex;padding:10px;" class="tic">
				<div style="width: 33%">
					<h3 style="margin-bottom: 10px;">Doctor</h3>
					<span><?php echo $doctorName ?></span>
				</div>
				<div style="width: 33%">
					<h3 style="margin-bottom: 10px;">Specialization</h3>
					<span><?php echo $specialization ?></span>
				</div>
				<div style="width: 33%">
					<h3 style="margin-bottom: 10px;">Contact</h3>
					<span><?php echo $contact ?></span>
				</div>
			</div>
			<p class="schedSuccess"><?php echo $schedSuccess ?></p>
			<form action="doctor.php" method="post" style="width: 500px;text-align: center;align-self: center;margin-top: 2%">
				<h3 style="margin-bottom: 20px;">Add Schedule</h3>
				<div style="display: flex;width: 100%;margin-bottom: 10px;">
					<div style="display: inline-flex; width: 50%;">
						<p style="margin: auto 0;">Date of Schedule: </p>
					</div>
					<div style="display: inline-flex; width: 50%">
						<input type="date" name="dateSched" id="dateSched" style="width: 100%">
					</div>
				</div>
				<div style="display: flex;width: 100%;margin-bottom: 10px;">
					<div style="display: inline-flex; width: 50%;">
						<p style="margin: auto 0;">Start Time: </p>
					</div>
					<div style="display: inline-flex; width: 50%">
					<input type="time" name="startTimeSched" id="startTimeSched" style="width: 100%">
					</div>
				</div>
				<div style="display: flex;width: 100%;margin-bottom: 10px;">
					<div style="display: inline-flex; width: 50%;">
						<p style="margin: auto 0;">Start Time of Schedule: </p>
					</div>
					<div style="display: inline-flex; width: 50%">
						<input type="time" name="endTimeSched" id="endTimeSched" style="width: 100%">
					</div>
				</div>
				<input type="hidden" name="doctorId" value="<?php echo $doctorId ?>">
				<p class="errorMessage"><?php echo $errormsg ?></p>
				<button type="submit" name="submitSched">Submit</button>
			</form>



		<form method="POST" style="display: none;">
			<table class="inputTable">
				<tr>
					<td>MONDAY</td>
					<td>
						<input type="time" name="mon">
					</td>
				</tr>
				<tr>
					<td>TUESDAY</td>
					<td>
						<input type="time" name="tues">
					</td>
				</tr>
				<tr>
					<td>WEDNESDAY</td>
					<td>
						<input type="time" name="wed">
					</td>
				</tr>
				<tr>
					<td>THURSDAY</td>
					<td>
						<input type="time" name="thur">
					</td>
				</tr>
				<tr>
					<td>FRIDAY</td>
					<td>
						<input type="time" name="fri">
					</td>
				</tr>
				<tr>
					<td>SATURDAY</td>
					<td>
						<input type="time" name="sat">
					</td>
				</tr>
				<tr>
					<td>SUNDAY</td>
					<td>
						<input type="time" name="sun">
					</td>
				</tr>
				<tr>
					<td colspan="2"><input type="submit" name="save" value="Save" class="edit" style="width: 100%;"></td>
				</tr>
			</table>
		</form>
		<?php 
			if(isset($_POST['save'])){
				$mon = $_POST['mon'];
				$tues = $_POST['tues'];
				$wed = $_POST['wed'];
				$thur = $_POST['thur'];
				$fri = $_POST['fri'];
				$sat = $_POST['sat'];
				$sun = $_POST['sun'];

				$insert = mysqli_query($con, "INSERT INTO schedule (doctor_id, mon, tues, wed, thur, fri, sat, sun) VALUES ('$doctor','$mon', '$tues', '$wed', '$thur', '$fri', '$sat', '$sun')");
				if(!$insert)
					echo "<script>alert('Unable to save!');</script>";
				else
					echo "<script>alert('Successfully saved!');</script>";
			}
		?>
	</section>

	<script>
		// Use Javascript
		var today = new Date();
		var dd = today.getDate();
		var mm = today.getMonth()+1; //January is 0 so need to add 1 to make it 1!
		var yyyy = today.getFullYear();
		if(dd<10){
			dd='0'+dd
		} 
		if(mm<10){
			mm='0'+mm
		} 

		today = yyyy+'-'+mm+'-'+dd;
		document.getElementById("dateSched").setAttribute("min", today);
	</script>

</body>
</html>