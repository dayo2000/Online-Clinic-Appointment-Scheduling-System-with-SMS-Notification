<?php
	$con = mysqli_connect("localhost", "root", "", "capstone");

	if(!$con)
		die("error");
?>