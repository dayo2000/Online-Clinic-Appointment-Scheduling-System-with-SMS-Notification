-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 28, 2021 at 02:06 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `capstone`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(255) NOT NULL,
  `patient_id` int(255) NOT NULL,
  `doctor_id` int(255) NOT NULL,
  `sched_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `startTime` time NOT NULL,
  `endTime` time NOT NULL,
  `stat` int(23) NOT NULL,
  `patient_name` varchar(224) NOT NULL,
  `patient_address` varchar(224) NOT NULL,
  `patient_contact` varchar(224) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `patient_id`, `doctor_id`, `sched_id`, `date`, `startTime`, `endTime`, `stat`, `patient_name`, `patient_address`, `patient_contact`) VALUES
(164, 1, 16, 3, '2021-12-01', '08:00:00', '12:00:00', 3, 'Mei Armellen  Songcuan', 'Calipahan, Talavera Nueva Ecija', '+63-926-6248-258'),
(168, 9, 16, 11, '2021-12-31', '10:00:00', '14:00:00', 3, 'Aerro Feria', 'Calipahan, Talavera Nueva Ecija', '+63-926-6248-258');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_schedule`
--

CREATE TABLE `doctor_schedule` (
  `id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `startTime` time NOT NULL,
  `endTime` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor_schedule`
--

INSERT INTO `doctor_schedule` (`id`, `doctor_id`, `date`, `startTime`, `endTime`) VALUES
(2, 16, '2021-11-30', '09:00:00', '12:00:00'),
(3, 16, '2021-12-01', '08:00:00', '12:00:00'),
(4, 16, '2021-12-02', '09:00:00', '12:30:00'),
(5, 16, '2021-12-03', '09:00:00', '14:00:00'),
(6, 16, '2021-12-04', '08:00:00', '14:00:00'),
(7, 16, '2021-12-06', '10:00:00', '14:00:00'),
(8, 16, '2021-12-07', '10:00:00', '16:00:00'),
(9, 16, '2021-12-29', '10:00:00', '15:00:00'),
(10, 16, '2021-12-30', '10:00:00', '15:00:00'),
(11, 16, '2021-12-31', '10:00:00', '14:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(255) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `doctor` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `firstname`, `lastname`, `doctor`, `email`, `contact`, `username`, `password`) VALUES
(16, 'Dianne ', 'Ronquillo', 'oby gyne', 'dianneronquillo2000@gmail.com', '+63-926-6248-258', 'dianne2000', '8cbbec26255dd7df1a1bdd7f32091d95');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(255) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `day` int(2) NOT NULL,
  `month` varchar(10) NOT NULL,
  `year` int(4) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `firstname`, `lastname`, `email`, `address`, `day`, `month`, `year`, `contact`, `username`, `password`) VALUES
(1, 'Mei Armellen ', 'Songcuan', 'meisongcuan99@gmail.com', 'Calipahan, Talavera Nueva Ecija', 10, 'February', 1999, '+63-926-6248-258', 'armellen99', '2bc37541121fbfa0f4ea25f130ffeaa7'),
(7, 'Taylor ', 'Swift', 'taylorswift1989@gmail.com', 'Buasao, Sto. Domingo Nueva Ecija', 10, 'February', 2000, '+63-926-6248-258', 'taylor1989', '0b5ef9d2fae4c6a7d42b953a5f63843f'),
(9, 'Aerro', 'Feria', 'aerroferia@gmail.com', 'Calipahan, Talavera Nueva Ecija', 14, 'December', 2000, '+63-926-6248-258', 'aerro123', '205cc9d325c15ce0fd8cc9906dc15900'),
(11, 'Karl', 'Barcelo', 'karlbarcelo@gmail.com', 'Calipahan, Talavera Nueva Ecija', 30, 'December', 1977, '+63-926-6248-258', 'karlkarl123', '51fd6dbec9e68c3fd1edda2f7e08c9b0'),
(12, 'Gel', 'Cunanan', 'gelcunanan123@gmail.com', 'Sumacab Este, Cabanatuan City', 9, 'October', 2010, '+63-926-6248-258', 'gcunanan123', '7144500a925e2995d4c18f27e1398fb3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor_schedule`
--
ALTER TABLE `doctor_schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=169;

--
-- AUTO_INCREMENT for table `doctor_schedule`
--
ALTER TABLE `doctor_schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
