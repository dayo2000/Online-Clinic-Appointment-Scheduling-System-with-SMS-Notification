<?php 
	include ('session.php');
	$con = mysqli_connect("localhost", "root", "", "capstone");
	$id = $_SESSION['id'];
	$errormsg = '';

	if(isset($_POST['submitSched'])){
		$date = $_POST['date'];
		$startTime = $_POST['startTimeSched'];
		$endTime = $_POST['endTimeSched'];
		$schedId = $_POST['schedId'];
		$doctor_id = $_POST['doctorId'];
		
		$sql = "SELECT * FROM doctor_schedule WHERE date='$date' AND id!='$schedId'";
		$result = mysqli_query($con, $sql);

		if (mysqli_num_rows($result) > 0) {
			$errormsg = "You already have a schedule on this date. Please choose another";
		}else{
			$sql = "UPDATE doctor_schedule SET date='$date',startTime='$startTime', endTime='$endTime' WHERE id='$schedId'";

			if (mysqli_query($con, $sql)) {
				header("Location:view.php");
			}
		}
	}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>CLinEx</title>
	<link rel="icon" href="doctor.png">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap5.min.css">
	<style type="text/css">
		* {
			padding: 0;
			margin: 0;
			box-sizing: border-box;
			font-family: arial, sans-serif;
		}
		.header {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 15px 30px;
			background: #23242b;
			color: #fff;
		}
		.u-name {
			font-size: 20px;
			padding-left: 17px;
		}
		.u-name b {
			color: #127b8e;
		}
		.header i {
			font-size: 30px;
			cursor: pointer;
			color: #fff;
		}
		.header i:hover {
			color: #127b8e;
		}
		.header h3{
			font-size: 20px;
		}
		.user-p {
			text-align: center;
			padding-left: 10px;
			padding-top: 25px;
		}
		.user-p img {
			width: 100px;
			border-radius: 50%;
		}
		.user-p h4 {
			color: #ccc;
			padding: 5px 0;

		}
		.side-bar {
			width: 250px;
			background: #262931;
			min-height: 100vh;
			transition: 500ms width;
		}
		.body {
			display: flex;
		}
		.section-1 {
			width: 100%;
			background: url("");
			background-size: cover;
			background-position: center;
			display: flex;
			flex-direction: column;
			padding: 5%;
		}
		.section-1 h1 {
			color: #004F13;
			font-size: 30px;
			margin: 10px auto;
		}
		.side-bar ul {
			margin-top: 20px;
			list-style: none;
		}
		.side-bar ul li {
			font-size: 16px;
			padding: 15px 0px;
			padding-left: 20px;
			transition: 500ms background;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}
		.side-bar ul li:hover {
			background: #127b8e;
		}
		.side-bar ul li a {
			text-decoration: none;
			color: #eee;
			cursor: pointer;
			letter-spacing: 1px;
		}
		.side-bar ul li a i {
			display: inline-block;
			padding-right: 10px;
			font-size: 23px;
		}
		#navbtn {
			display: inline-block;
			margin-left: 70px;
			font-size: 20px;
			transition: 500ms color;
		}
		#checkbox {
			display: none;
		}
		#checkbox:checked ~ .body .side-bar {
			width: 60px;
		}
		#checkbox:checked ~ .body .side-bar .user-p{
			visibility: hidden;
		}
		#checkbox:checked ~ .body .side-bar a span{
			display: none;
		}
		h5{
			font-size: 30px;
			margin: 20px auto;
			color: #004F13;

		}
		.dataTable th {
    		padding: 15px;
		}

		.dataTable thead {
			font-size: 20px;
			background: #1b7b8e;
			color: #fff;
			padding: 20px;
		}
		.dataTable td {
			padding: 20px;
		}
		.dataTable tbody > tr {
			text-align: center;
			font-size: 16px;
		}
		.dataTable tr.odd {
			background: #f1f1f1;
		}
		.dataTable tbody > tr:hover{
			background: #f1f1f1;
		}
		.paginate_button {
			background: #1b7b8e;
			color: #fff;
			padding: 10px;
			margin: 10px 5px;
			border-radius: 5px;
		}
		div#all-records_paginate {
			margin-top: 20px;
			padding: 20px;
		}
		.dataTables_filter input[type="search"] {
			border-radius: 5px;
			padding: 5px;
			text-align: left;
			border: 1px solid #000;
		}
		.crudButtons-div{
			display: block;
			text-align: center;
    		margin: 30px auto;
		}
		.crudButton{
			font-size:20px;
			color: white;
			border: none;
			text-decoration: none;
			border-radius: 5px;
			padding: 10px;
			display: inline;
		}
		.row {
			display: block;
			width: 300px;
			margin: 10px auto;
			align-items: center;
		}
		.row label{
			font-size: 14px;
		}
		.row > input{
			display: block;
			width: 100%;
			padding: 10px;
			margin: auto;
		}
		.row > .save{
			background: #1b7b8e;
			color: #fff;
			border: none;
			border-radius: 0px;
			font-size: 16px;
			font-weight: 500;
		}
		a.editSched {
			background: #1b7b8e;
			color: #fff;
			text-decoration: none;
			padding: 10px 20px;
		}
		input,select {
			color: black;
			border: 1px solid #404040;
			border-radius: 5px;
			padding: 10px;
		}
		button[type=submit]{
			background: #1b7b8e;
			color: #FFF;
			border: none;
			width: 100%;
			padding: 7px;
		}
		.errorMessage{
			color: red;
			font-size: 14px;
			margin-bottom: 10px;
		}
		.schedSuccess{
			color: green;
			font-size: 20px;
			margin: 10px auto;
		}
	</style>
</head>
<body>
<input type="checkbox" id="checkbox">
	<header class="header">
		<h2 class="u-name">Clin <b>Ex</b>
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
		<h3>Doctor</h3>
		</h2>
	</header>
	<div class="body">
		<nav class="side-bar">
			<div class="user-p">
				<?php
					$select = mysqli_query($con, "SELECT * FROM registration WHERE username = '$_SESSION[username]'");

					while ($count = mysqli_fetch_array($select)) {
				?>	
				<h4><?php echo "Dra. " .$count['firstname'] .$count['lastname']; ?></h4>
				<?php
					}
				?>
			</div>
			<ul>
				<li>
					<a href="dashboard.php">
						<i class="fa fa-dashboard" aria-hidden="true"></i>
						<span>Dashboard</span>
					</a>
				</li>
				<li>
					<a href="doctor.php">
						<i class="fa fa-user-md" aria-hidden="true"></i>
						<span>Doctor</span>
					</a>
				</li>
				<li>
					<a href="patient.php">
						<i class="fa fa-stethoscope" aria-hidden="true"></i>
						<span>Patient</span>
					</a>
				</li>
				<li>
					<a href="appointment.php">
						<i class="fa fa-calendar" aria-hidden="true"></i>
						<span>Appointment</span>
					</a>
				</li>
				<li>
					<a href="record.php">
						<i class="	fa fa-address-book" aria-hidden="true"></i>
						<span>Record</span>
					</a>
				</li>
				<li>
					<a href="logout.php">
						<i class="fa fa-sign-out" aria-hidden="true"></i>
						<span>Logout</span>
					</a>
				</li>
			</ul>
		</nav>
		<section class="section-1">
			<h1>EDIT SCHEDULE</h1>

			<div class="crudButtons-div">
				<a href="view.php" class="fa fa-eye view crudButton" style="background-color: #1b7b8e;">View</a>
				<a href="edit.php" class="fa fa-edit edit crudButton" style="background-color: #18871E;">Update</a>
				<a href="delete.php" class="fa fa-trash-o delete crudButton" style="background-color: #c30000;">Delete</a>
			</div>

			<div style="width: 500px;text-align: center;align-self: center;margin-top: 2%">
				<form action="edit.php" method="post">
					<div style="display: flex;width: 100%;margin-bottom: 10px;">
						<div style="display: inline-flex; width: 50%;">
							<p style="margin: auto 0;">Date of Schedule: </p>
						</div>
						<div style="display: inline-flex; width: 50%">
							<select name="date" id="date" style="width: 100%;">
								<?php
									$sql = "SELECT * FROM doctor_schedule WHERE doctor_id='$id' AND date >= now()";
									$result = mysqli_query($con, $sql);

									if (mysqli_num_rows($result) > 0) {
										while($row = mysqli_fetch_assoc($result)) {
											echo '<option id="'.$row['id'].'" value="'.$row['date'].'">'.date('F d - l',strtotime($row['date'])).'</option>';
										}
									}
								?>
								
							</select>
						</div>
					</div>
					<div style="display: flex;width: 100%;margin-bottom: 10px;">
						<div style="display: inline-flex; width: 50%;">
							<p style="margin: auto 0;">Start Time: </p>
						</div>
						<div style="display: inline-flex; width: 50%">
						<input type="time" name="startTimeSched" id="startTimeSched" style="width: 100%">
						</div>
					</div>
					<div style="display: flex;width: 100%;margin-bottom: 10px;">
						<div style="display: inline-flex; width: 50%;">
							<p style="margin: auto 0;">Start Time of Schedule: </p>
						</div>
						<div style="display: inline-flex; width: 50%">
							<input type="time" name="endTimeSched" id="endTimeSched" style="width: 100%">
						</div>
					</div>
					<input type="hidden" name="doctorId" id="doctorId" value="">
					<input type="hidden" name="schedId" id="schedId" value="">
					<p class="errorMessage"><?php echo $errormsg ?></p>
					<button type="submit" name="submitSched">Update</button>
				</form>
			</div>
		</section>

	<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script>
		$('#date').ready(function() {
			var id = $(this).find('option:selected').attr('id');
			$.ajax({
				type: "GET",
				url: "editData.php?id="+id,
				async: false,
				success: function(response) {
					var returnedData = JSON.parse(response);
					$('#doctorId').val(returnedData.doctorId);
					$('#schedId').val(returnedData.id);
					$('#startTimeSched').val(returnedData.start);
					$('#endTimeSched').val(returnedData.end);
				}
			});
		});
		$('select').on('change', function() {
			var id = $(this).find('option:selected').attr('id');
			$.ajax({
				type: "GET",
				url: "editData.php?id="+id,
				async: false,
				success: function(response) {
					var returnedData = JSON.parse(response);
					$('#doctorId').val(returnedData.doctorId);
					$('#schedId').val(returnedData.id);
					$('#startTimeSched').val(returnedData.start);
					$('#endTimeSched').val(returnedData.end);
				}
			});
		});
	</script>
	
	
</body>
</html>

<!-- 
	
		if(isset($_GET['doctor_id'])){
			$doctor = $_GET['doctor_id'];
			$select = mysqli_query($con, "SELECT * FROM schedule WHERE doctor_id = '$doctor'");
			while($row = mysqli_fetch_array($select)){
	?>
			<form method="post">
				<div class="row">
					<label for="mon">MONDAY</label>
					<input type="time" name="mon">
				</div>
				<div class="row">
					<label for="tues">TUESDAY</label>
					<input type="time" name="tues">
				</div>
				<div class="row">
					<label for="wed">WEDNESDAY</label>
					<input type="time" name="wed">
				</div>
				<div class="row">
					<label for="thur">THURSDAY</label>
					<input type="time" name="thur">
				</div>
				<div class="row">
					<label for="fri">FRIDAY</label>
					<input type="time" name="fri">
				</div>
				<div class="row">
					<label for="sat">SATURDAY</label>
					<input type="time" name="sat">
				</div>
				<div class="row">
					<label for="sun">SUNDAY</label>
					<input type="time" name="sun">
				</div>
				<div class="row">
					<input type="submit" name="save" value="Save" class="save">
				</div>
			</form>

			}
		}

	?>

	<div>
		<table id="all-records" style="width: 100%;">
			<thead>
				<tr>
					<th>Monday</th>
					<th>Tuesday</th>
					<th>Wednesday</th>
					<th>Thursday</th>
					<th>Friday</th>
					<th>Saturday</th>
					<th>Sunday</th>
					<th>Action</th>
				</tr>
			</thead>
		</table>
	</div>
	 	if(isset($_POST['save'])){
			$mon = $_POST['mon'];
			$tues = $_POST['tues'];
			$wed = $_POST['wed'];
			$thur = $_POST['thur'];
			$fri = $_POST['fri'];
			$sat = $_POST['sat'];
			$sun = $_POST['sun'];
			$update = mysqli_query($con, "UPDATE schedule SET mon='$mon', tues='$tues', wed='$wed', thur='$thur', fri='$fri', sat='$sat', sun='$sun' WHERE doctor_id='$doctor'");
			if(!$update)
				echo "<script>alert('Unable to update');</script>";
			else
				echo "<script>alert('Data successfully updated!');window.location.href='edit.php?doctor_id=$doctor';</script>";
			/*header("location:edit.php");*/
	 	}

	  ?>

  <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.0.1/js/dataTables.buttons.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.html5.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.print.min.js"></script>

  <script>
    var allRecords = $('#all-records').DataTable( {
        "dom": '<<f> <t> < p> >',
        "processing": true,
        "searching": true,
        "order": [[ 4, "desc" ]],
        "buttons": [ 'pdf'
        ],
        initComplete: function () {
          this.api().columns([0,1,2,3,4,5]).every( function () {
            var column = this;
            var select = $('<select class="form-control select2bs4" style="width: 100%;"><option value=""></option></select>')
              .appendTo( $(column.footer()).empty() )
              .on( 'change', function () {
                var val = $.fn.dataTable.util.escapeRegex(
                  $(this).val()
                );

                column
                  .search( val ? '^'+val+'$' : '', true, false )
                  .draw();
              });

            column.cells('', column[0]).render('display').sort().unique().each( function ( d, j ) {
              select.append('<option value="' + d + '">' + d.substr(0,30) + '</option>')
            });
          });
        },
        "paging": true,
        "pagingType": "simple",
        "bLengthChange": false,
        "language": {
          'search': '',
          'searchPlaceholder': "Search...",
          'emptyTable': "No results found",
        },
        "ajax": {
          "url": "schedulesReport.php",
          "type": "POST",
        },
        "columns": [
          { "data": "monday" },
          { "data": "tuesday" },
          { "data": "wednesday" },
          { "data": "thursday" },
		  { "data": "friday" },
          { "data": "saturday" },
          { "data": "sunday" },
		  {
            "data": null,
			"render":function ( data, type, row, meta) {
				return '<a href="edit.php?doctor_id='+row.doctor_id+'" class="editSched">Edit</a>';
			}
          },
        ],
    });

  </script> -->