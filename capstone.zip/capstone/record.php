<?php
	include("session.php");
	$con = mysqli_connect("localhost", "root", "", "capstone");

	if(isset($_GET['delete'])){
		$id = $_GET['delete'];
		$delete = mysqli_query($con, "DELETE FROM appointments WHERE id = $id ");
		if(!$delete)
			die("error");
		else{
			header("Location: record.php");
		}
	}

	if(isset($_POST['editSched'])){
		
		$appntmentId = $_POST['appointmentId'];
		$date = $_POST['date'];
		$startTime = $_POST['startTime'];
		$endTime = $_POST['endTime'];

		$sql = "UPDATE appointments SET date='$date',startTime='$startTime',endTime='$endTime' WHERE id='$appntmentId'";
		if (mysqli_query($con, $sql)) {
			header("Location: record.php");
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>CLinEx</title>
	<link rel="icon" href="doctor.png">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap5.min.css">
	<style type="text/css">
		* {
		padding: 0;
		margin: 0;
		box-sizing: border-box;
		font-family: arial, sans-serif;
		}
		.header {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 15px 30px;
			background: #23242b;
			color: #fff;
		}
		.u-name {
			font-size: 20px;
			padding-left: 17px;
		}
		.u-name b {
			color: #127b8e;
		}
		.header i {
			font-size: 30px;
			cursor: pointer;
			color: #fff;
		}
		.header i:hover {
			color: #127b8e;
		}
		.header h3{
			font-size: 20px;
		}
		.user-p {
			text-align: center;
			padding-left: 10px;
			padding-top: 25px;
		}
		.user-p img {
			width: 100px;
			border-radius: 50%;
		}
		.user-p h4 {
			color: #ccc;
			padding: 5px 0;

		}
		.side-bar {
			width: 250px;
			background: #262931;
			min-height: 100vh;
			transition: 500ms width;
		}
		.body {
			display: flex;
		}
		.section-1 {
			width: 100%;
			background: url("");
			background-size: cover;
			background-position: center;
			display: flex;
			flex-direction: column;
			padding: 5%;
		}
		.section-1 h1 {
			color: #fff;
			font-size: 60px;
		}
		.section-1 p {
			color: #127b8e;
			font-size: 20px;
			background: #fff;
			padding: 7px;
			border-radius: 5px;
		}
		.side-bar ul {
			margin-top: 20px;
			list-style: none;
		}
		.side-bar ul li {
			font-size: 16px;
			padding: 15px 0px;
			padding-left: 20px;
			transition: 500ms background;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}
		.side-bar ul li:hover {
			background: #127b8e;
		}
		.side-bar ul li a {
			text-decoration: none;
			color: #eee;
			cursor: pointer;
			letter-spacing: 1px;
		}
		.side-bar ul li a i {
			display: inline-block;
			padding-right: 10px;
			font-size: 23px;
		}
		#navbtn {
			display: inline-block;
			margin-left: 70px;
			font-size: 20px;
			transition: 500ms color;
		}
		#checkbox {
			display: none;
		}
		#checkbox:checked ~ .body .side-bar {
			width: 60px;
		}
		#checkbox:checked ~ .body .side-bar .user-p{
			visibility: hidden;
		}
		#checkbox:checked ~ .body .side-bar a span{
			display: none;
		}
		input{
			text-align:center;
			padding: 5px;
			margin: 5px;
		}
		h5{
			font-size: 30px;
			margin: 20px auto;
			color: #004F13;

		}
		.dataTable th {
    		padding: 15px;
		}

		.dataTable thead {
			font-size: 20px;
			background: #1b7b8e;
			color: #fff;
			padding: 20px;
		}
		.dataTable td {
			padding: 20px;
		}
		.dataTable tbody > tr {
			text-align: center;
			font-size: 16px;
		}
		.dataTable tr.odd {
			background: #f1f1f1;
		}
		.dataTable tbody > tr:hover{
			background: #f1f1f1;
		}
		.paginate_button {
			background: #1b7b8e;
			color: #fff;
			padding: 10px;
			margin: 10px 5px;
			border-radius: 5px;
		}
		div#all-records_paginate {
			margin-top: 20px;
			padding: 20px;
			display: inline-block;
			float: right;
		}
		.dataTables_filter input[type="search"] {
			border-radius: 5px;
			padding: 5px;
			text-align: left;
			border: 1px solid #000;
		}
		a.edit {
			background: #127b8e;
			color: #fff;
			padding: 10px;
			margin-right: 10px;
			text-decoration: none;
		}
		a.delete {
			background: #00000000;
			color: #000;
			border: 1px solid #838383;
			padding: 10px;
			text-decoration: none;
		}
		.editTable{
			text-align: center;
			margin: 30px auto;
		}
		.editTable th {
			color: #fff;
			background: #1b7b8e;
			padding: 15px;
		}
		.editTable select {
			padding: 5px;
		}
		.editTable button{
			background: #127b8e;
			color: #fff;
			padding: 10px;
			margin-right: 10px;
			text-decoration: none;
			border: none;
		}
		.dt-buttons{
			display: inline-block;
			margin-top: 20px;
		}
		.dt-button{
			background: #127b8e;
			color: #fff;
			padding: 10px;
			margin-right: 10px;
			text-decoration: none;
			border: none;
			border-radius: 5px;
		}
	</style>	
</head>
<body>
	<header class="header">
		<h2 class="u-name">Clin <b>Ex</b>
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
		<h3>Record</h3>
		</h2>
	</header>
	<div class="body">
		<nav class="side-bar">
			<div class="user-p">
				<?php
					$select = mysqli_query($con, "SELECT * FROM registration WHERE username = '$_SESSION[username]'");

					while ($count = mysqli_fetch_array($select)) {
				?>	
				<h4><?php echo "Dra. " .$count['firstname'] .$count['lastname']; ?></h4>
				<?php
					}
				?>
			</div>
			<ul>
				<li>
					<a href="dashboard.php">
						<i class="fa fa-dashboard" aria-hidden="true"></i>
						<span>Dashboard</span>
					</a>
				</li>
				<li>
					<a href="doctor.php">
						<i class="fa fa-user-md" aria-hidden="true"></i>
						<span>Doctor</span>
					</a>
				</li>
				<li>
					<a href="patient.php">
						<i class="fa fa-stethoscope" aria-hidden="true"></i>
						<span>Patient</span>
					</a>
				</li>
				<li>
					<a href="appointment.php">
						<i class="fa fa-calendar" aria-hidden="true"></i>
						<span>Appointment</span>
					</a>
				</li>
				<li>
					<a href="record.php">
						<i class="	fa fa-address-book" aria-hidden="true"></i>
						<span>Record</span>
					</a>
				</li>
				<li>
					<a href="logout.php">
						<i class="fa fa-sign-out" aria-hidden="true"></i>
						<span>Logout</span>
					</a>
				</li>
			</ul>
		</nav>
		<section class="section-1">
			<h5>PATIENT RECORDS</h5>
			<?php
				if(isset($_GET['edit'])){
					$appointmentId = $_GET['edit'];
					echo "
					<form method='post'>
						<table class='editTable'>
							<tr>
								<th>Patient Name</th>
								<th>Date</th>
								<th>Start Time</th>
								<th>End Time</th>
								<th>Action</th>
							</tr>
					";
					$sql = "SELECT * FROM appointments WHERE id='$appointmentId'";
					$result = mysqli_query($con, $sql);
					if (mysqli_num_rows($result) > 0) {
						echo "<tr>";
						while($row = mysqli_fetch_assoc($result)) {
							$doctor_id = $row['doctor_id'];
							echo "<td>".$row['patient_name']."<input name='appointmentId' value='".$appointmentId."' hidden></td>";
							echo '<td><input type="date" name="date" id="date" value="'.$row['date'].'"></td>';
							echo '<td><input type="time" name="startTime" id="startTime" value="'.$row['startTime'].'"></td>';
							echo '<td><input type="time" name="endTime" id="endTime" value="'.$row['endTime'].'"></td>';
						}
						echo "
								<td><button type='submit' name='editSched'>Submit</button><td></tr>
							";
					}
					echo "</table></form>";
				}
			?>
			<div>
				<table id="all-records" style="width: 100%;">
					<thead>
						<tr>
							<th>#</th>
							<th>Patient</th>
							<th>Address</th>
							<th>Mobile Number</th>
							<th>Date</th>
							<th>Start Time</th>
							<th>End Time</th>
							<th>Action</th>
						</tr>
					</thead>
				</table>
			</div>
		</section>
	</div>

  <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.0.1/js/dataTables.buttons.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.html5.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.print.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
	<script src="https://cdn.datatables.net/datetime/1.1.1/js/dataTables.dateTime.min.js"></script>
	<script src="http://cdn.datatables.net/plug-ins/1.10.15/dataRender/datetime.js"></script>
  <script>
    var allRecords = $('#all-records').DataTable( {
        "dom": '<<f> <t> <B p> >',
        "processing": true,
		"buttons": [
			"print",
		],
        "searching": true,
        "order": [[ 4, "desc" ]],
        "paging": true,
        "pagingType": "simple",
        "bLengthChange": false,
        "language": {
          'search': '',
          'searchPlaceholder': "Search...",
          'emptyTable': "No results found",
        },
        "ajax": {
          "url": "recordsReport.php",
          "type": "POST",
        },
        "columns": [
          { "data": "patient_id" },
          { "data": "patient_name" },
          { "data": "patient_address" },
          { "data": "patient_contact" },
          { "data": "date", },
		  { "data": "startTime", },
		  { "data": "endTime", },
		  {
            "data": null,
			"render":function ( data, type, row, meta) {
				return '<a href="record.php?edit='+data.id+'" name="edit" class="edit">Edit</a><a a href="record.php?delete='+data.id+'" name="delete" class="delete">Delete</a>';
			}
          },
        ],
		"columnDefs": [
          { targets: 4, render: $.fn.dataTable.render.moment( 'dddd - MMMM D ' ) },
    	]
    });

  </script>

</body>
</html>