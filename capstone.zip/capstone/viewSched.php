<?php

include ('session.php');
include ("database.php");

$id = $_SESSION['id'];

$sched = array();

$sql = "SELECT * FROM doctor_schedule WHERE doctor_id='$id'";
$result = mysqli_query($con, $sql);

if (mysqli_num_rows($result) > 0) {
  while($row = mysqli_fetch_assoc($result)) {
    $array = array(
      'title' => "Schedule on " .date('l',strtotime($row['date'])),
      'start' => $row['date']. " " . $row['startTime'],
      'end' => $row['date']. " " . $row['endTime'],
    );
    array_push($sched, $array);
  }
  echo json_encode($sched);
}

?>