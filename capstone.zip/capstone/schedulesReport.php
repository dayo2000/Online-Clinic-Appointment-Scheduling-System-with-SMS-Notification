<?php

    include ('session.php');

    $id = $_SESSION['id'];

    $table = 'schedule';
    
    // Table's primary key
    $primaryKey = 'id';
    
    // Array of database columns which should be read and sent back to DataTables.
    // The `db` parameter represents the column name in the database, while the `dt`
    // parameter represents the DataTables column identifier. In this case object
    // parameter names
    $columns = array(
        array( 'db' => 'mon', 'dt' => 'monday' ),
        array( 'db' => 'tues',  'dt' => 'tuesday' ),
        array( 'db' => 'wed',   'dt' => 'wednesday' ),
        array( 'db' => 'thur',   'dt' => 'thursday' ),
        array( 'db' => 'fri',   'dt' => 'friday' ),
        array( 'db' => 'sat',   'dt' => 'saturday' ),
        array( 'db' => 'sun',   'dt' => 'sunday' ),
        array( 'db' => 'doctor_id',   'dt' => 'doctor_id' ),
    );
    
    // SQL server connection information
    $sql_details = array(
        'user' => 'root',
        'pass' => '',
        'db'   => 'capstone',
        'host' => 'localhost'
    );
    
    
    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
    * If you just want to use the basic configuration for DataTables with PHP
    * server-side, there is no need to edit below this line.
    */
    
    require( 'ssp.class.php' );
    $where = "doctor_id=".$id;
    echo json_encode(
        SSP::complex( $_POST, $sql_details, $table, $primaryKey, $columns, $where )
    );

?>