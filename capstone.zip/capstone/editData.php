<?php

include ('session.php');
include ("database.php");

$id = $_GET['id'];

$sql = "SELECT * FROM doctor_schedule WHERE id='$id'";
$result = mysqli_query($con, $sql);

if (mysqli_num_rows($result) > 0) {
  while($row = mysqli_fetch_assoc($result)) {
    $array = array(
      'id' => $row['id'],
      'doctorId' => $row['doctor_id'],
      'start' =>  $row['startTime'],
      'end' => $row['endTime'],
    );
  }
  echo json_encode($array);
}

?>